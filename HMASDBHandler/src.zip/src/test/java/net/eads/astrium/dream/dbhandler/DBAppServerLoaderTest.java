/**
 * --------------------------------------------------------------------------------------------------------
 *   Project                                            :               DREAM
 * --------------------------------------------------------------------------------------------------------
 *   File Name                                          :               DBAppServerLoaderTest.java
 *   File Type                                          :               Source Code
 *   Description                                        :                *
 * --------------------------------------------------------------------------------------------------------
 *
 * =================================================================
 *             (coffee) COPYRIGHT EADS ASTRIUM LIMITED 2013. All Rights Reserved
 *             This software is supplied by EADS Astrium Limited on the express terms
 *             that it is to be treated as confidential and that it may not be copied,
 *             used or disclosed to others for any purpose except as authorised in
 *             writing by this Company.
 * --------------------------------------------------------------------------------------------------------
 *//*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.eads.astrium.dream.util.structures.SatellitePlatform;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author re-sulrich
 */
public class DBAppServerLoaderTest {
    private String url;
    private String user;
    private String passwd;
    private FASApplicationLoader appServerLoader;
    
    
    @Before
    public void init() {
        
        url = "jdbc:postgresql://10.2.200.247:5432/MMFASDatabase";
//        url = "jdbc:postgresql://192.168.0.20:5432/MMFASDatabase";

        user = "opensourcedbms";
        passwd = "opensourcedbms";
        appServerLoader = new FASApplicationLoader("1", url, user, passwd);
    }
    
//    @Test
    public void testCreateDir() throws SQLException, IOException {
        appServerLoader.createFASConfigurationFileFolder();
    }
    
//    @Test
    public void testgetGSFile() throws SQLException, IOException {
        
//        String url = "jdbc:postgresql://10.2.200.247:5432/MMFASDatabase";
        
        appServerLoader.getGroundStationFiles("C:\\Users\\re-sulrich\\.dream\\fas\\00001AAA\\Ground Station\\", "00001AAA");
        
    }
    
//    @Test
    public void testgetOSFFile() throws SQLException, IOException {
        
        appServerLoader.getOSFFiles("C:\\Users\\re-sulrich\\.dream\\fas\\00001AAA\\OSF\\", "00001AAA");
    }
    
//    @Test
    public void testgetSDFFile() throws SQLException, IOException {
        
        appServerLoader.getSDFFiles("C:\\Users\\re-sulrich\\.dream\\fas\\00001AAA\\sensors\\S1SAR\\SDF\\", "S1SAR");
    }
//    @Test
    public void testgetSCFFile() throws SQLException, IOException {
        
        appServerLoader.getSatelliteConfigurationFile("C:\\Users\\re-sulrich\\.dream\\fas\\00001AAA\\", "'00001AAA'");
    }
    
//    @Test
    public void testGetAntSDFFile() throws SQLException, IOException {
        appServerLoader.getAntennaSDF("C:\\Users\\re-sulrich\\.dream\\fas\\00001AAA\\", "00001AAA");
    }
    
//    @Test
    public void testDoubleFormatter() throws ParseException {
//        System.out.println("" + ApplicationServerLoader.getFormattedDouble(1.0));
        
        double d = 12.32412213;
        
        System.out.println("" + FASApplicationLoader.getFormattedDouble(d));
    }
    
    
    
    @Test
    public void testSortSatellitesPerSensorType() throws SQLException {
        MMFASHandler handler = new MMFASHandler("gmes-mmfas", url, user, passwd);
//        
//        
//        List<String> cond = new ArrayList<String>();
//        cond.add("SatellitePlatform.satelliteId in "
//                + "(SELECT satellite FROM LNK_MMFAS_Satellite WHERE mmfas = 'gmes-mmfas')"
//            );
//        cond.add("Sensor.platform=SatellitePlatform.satelliteId");
//        cond.add("Sensor.type='OPT'");
//        List<List<String>> res = handler.select(Arrays.asList(new String[]{"sensorId"}), "Sensor, SatellitePlatform", cond);
//        
//        
//        System.out.println("" + res.size() + "   -    " + res.get(0).get(0));
        List<SatellitePlatform> res = handler.getSatellites("SAR");
        for (SatellitePlatform satellitePlatform : res) {
            System.out.println("" + satellitePlatform.getId());
        }
    }
}
