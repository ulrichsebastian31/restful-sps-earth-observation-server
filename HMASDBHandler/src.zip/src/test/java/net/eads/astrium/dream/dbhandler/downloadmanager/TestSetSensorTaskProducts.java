/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler.downloadmanager;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import net.eads.astrium.dream.dbhandler.tasking.SensorPlanningHandler;
import net.eads.astrium.dream.util.structures.downloadmanager.Product;
import net.eads.astrium.dream.util.structures.tasking.Segment;
import org.junit.Test;

/**
 *
 * @author re-sulrich
 */
public class TestSetSensorTaskProducts {
    
    @Test
    public void test() throws SQLException, ParseException {
        String sensorPlanningTaskId = "6";
        String dmID = "442143e70eddb7768e30f2bc16f024e7";
        
        //A remplacer par tes DB
        String mmfasDBUrl = "jdbc:postgresql://192.168.0.20:5432/MMFASDatabase";
        String dmDBUrl = "jdbc:postgresql://192.168.0.20:5432/DownloadManagerDatabase";

        String user = "opensourcedbms";
        String passwd = "opensourcedbms";
        
        SensorPlanningHandler sph = new SensorPlanningHandler(mmfasDBUrl, user, passwd);
        DownloadManagerManagementHandler dmm = new DownloadManagerManagementHandler(dmDBUrl, user, passwd);
        
        //Lire tous les segments de la sensorTask de la base de donnees (MMFASDatabase)
        List<Segment> segments = sph.getSegments(sensorPlanningTaskId);
        //Ajouter une DAR au download manager choisi
        String darID = dmm.addNewDAR(dmID, null, sensorPlanningTaskId);
        //Pour tous les segments de la SensorTask
        for (Segment segment : segments) {
            //Pour tous les produits du segment
            List<Product> prods = dmm.getSegmentProducts(segment.getSegmentId());
            for (Product product : prods) {
                //Ajouter le lien entre le produit et la DAR
                //Avec la fin du Downlink du segment qui a ete lu dans la base de donnees (MMFASDatabase)
                dmm.addNewProductDownload(darID, product.getProductID(), 
                    "This product will be acquired on "+
                    segment.getGroundStationDownlink().getEndOfVisibility().getTime()+".");
            }
        }
    }
}
