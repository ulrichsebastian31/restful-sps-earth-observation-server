/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler.downloadmanager;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import static net.eads.astrium.dream.dbhandler.downloadmanager.TestInsertUpdate.timeFirstDARInsert;
import net.eads.astrium.dream.util.DateHandler;
import net.eads.astrium.dream.util.structures.downloadmanager.Download;
import net.eads.astrium.dream.util.structures.downloadmanager.errors.DMMError;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author re-sulrich
 */
public class TestSelect {
    
    private static DownloadManagerManagementHandler dmm;
    
    @BeforeClass
    public static void init() {
        
        String url = "jdbc:postgresql://10.2.200.247:5432/DownloadManagerDatabase";
//        String url = "jdbc:postgresql://192.168.0.20:5432/DownloadManagerDatabase";

        String user = "opensourcedbms";
        String passwd = "opensourcedbms";
        
        dmm = new DownloadManagerManagementHandler(url, user, passwd);
    }
    
    
    @Test
    public void test() throws SQLException, ParseException {
        
//        testSelectUser();
//        System.out.println("");
//        testIsDMReg();
//        System.out.println("");
//        testIsDMNotReg();
//        System.out.println("");
//        testGetDM();
//        System.out.println("");
//        testGetProd();
//        System.out.println("");
//        testGetUserDMs();
//        System.out.println("");
//        testGetNBMAXDMUser();
//        System.out.println("DM DARs : ");
//        testGetDMDARs();
//        System.out.println("After : ");
//        testGetDMDARsAfter();
//        System.out.println("All : ");
//        testGetDMProducts();
//        System.out.println("Ready : ");
//        testGetReadyDMProducts();
//        System.out.println("Ready accessed : ");
//        testGetReadyAccessedDMProducts();
//        System.out.println("");
//        testGetDMErrors();
//        System.out.println("");
//        testGetDownloadErrors();
//        System.out.println("");
//        testGetRefresh();
//        System.out.println("");
//        testGetDARs();
        System.out.println("");
        testGetLeastUsedDM();
    }
    
    public void testGetLeastUsedDM() throws SQLException, ParseException {
        List<String> dms = dmm.getDownloadManagers(TestInsertUpdate.user1);
        String dmID = null;
        if (dms != null && !dms.isEmpty()) {
            int minDMDARs = dmm.getDataAccessRequestsIDs(dms.get(0), null).size();

            for (String dm : dms) {
                System.out.print("DM : " + dm + " - ");
                List<String> dars = dmm.getDataAccessRequestsIDs(dm, null);
                if (minDMDARs > dars.size()) {
                    dmID = dm;
                }
                System.out.println("Nb dars : " + dars.size());
            }
        }
        System.out.println("Res : " + dmID);
    }
    
    public void testGetRefresh() throws ParseException, SQLException {
        System.out.println("" + dmm.getDownloadManagerRefreshTime(TestInsertUpdate.dm1));
    }
    
    public void testGetDARs() throws ParseException, SQLException {
        
            List<String> dars = dmm.getDataAccessRequestsIDs(TestInsertUpdate.dm1, null);
            for (String dar : dars) {
                System.out.println("DAR : " + dar);
                System.out.println("" + dmm.getDAR(dar));
            }
            dars = dmm.getDataAccessRequestsIDs(TestInsertUpdate.dm2, null);
            for (String dar : dars) {
                System.out.println("DAR : " + dar);
                System.out.println("" + dmm.getDAR(dar));
            }
    }
    
    public void testSelectUser() throws SQLException {
        
        System.out.println("" + dmm.getUser(TestInsertUpdate.user1));
    }
    
    public void testIsDMReg() throws SQLException {
        
        System.out.println("" + dmm.isDownloadManagerRegistered(TestInsertUpdate.dm1));
    }
    
    //Tests a random DM that is not existing
    public void testIsDMNotReg() throws SQLException {
        
        System.out.println("" + dmm.isDownloadManagerRegistered("5ae3e04b833ef6a44336095fd227dee9"));
    }
    
    public void testGetDM() throws ParseException, SQLException {
        System.out.println("" + dmm.getDownloadManager(TestInsertUpdate.dm1));
    }
    
    public void testGetProd() throws ParseException, SQLException {
        System.out.println("" + dmm.getProduct("1"));
        System.out.println("" + dmm.getProduct("2"));
    }
    
    public void testGetUserDMs() throws SQLException {
        List<String> dms = dmm.getDownloadManagers(TestInsertUpdate.user1);
        System.out.println("User 1");
        for (String string : dms) {
            System.out.println("" + string);
        }
        System.out.println("User 2");
        dms = dmm.getDownloadManagers(TestInsertUpdate.user2);
        for (String string : dms) {
            System.out.println("" + string);
        }
    }
    
    public void testGetNBMAXDMUser() throws SQLException {
        System.out.println("max : " + dmm.getUserMaxDownloadManagers(TestInsertUpdate.user1));
        System.out.println("nb : " + dmm.getUserNbDownloadManagers(TestInsertUpdate.user1));
    }
    
    
    public void testGetDMDARs() throws SQLException, ParseException {
        
        List<String> dms = dmm.getDownloadManagers(TestInsertUpdate.user1);
        for (String dm : dms) {
            System.out.println("DM : " + dm);
            List<String> dars = dmm.getDataAccessRequestsIDs(dm, null);
            for (String dar : dars) {
                System.out.println("DAR : " + dar);
            }
        }
    }
    
    public void testGetDMDARsAfter() throws SQLException, ParseException {
        
        timeFirstDARInsert = DateHandler.getCalendar(DateHandler.parseDate("2013-08-01"));
        
        List<String> dms = dmm.getDownloadManagers(TestInsertUpdate.user1);
        for (String dm : dms) {
            System.out.println("DM : " + dm);
            List<String> dars = dmm.getDataAccessRequestsIDs(dm, TestInsertUpdate.timeFirstDARInsert.getTime());
            for (String dar : dars) {
                System.out.println("DAR : " + dar);
            }
        }
    }
    
    public void testGetDMProducts() throws ParseException, SQLException {
        List<String> dms = dmm.getDownloadManagers(TestInsertUpdate.user1);
        for (String dm : dms) {
            System.out.println("DM : " + dm);
            List<String> dars = dmm.getDataAccessRequestsIDs(dm, null);
            for (String dar : dars) {
                System.out.println("DAR : " + dar);
                List<Download> prods = dmm.getProducts(dar, null);
                for (Download product : prods) {
                    System.out.println("" + product);
                }
            }
        }
    }

    public void testGetReadyDMProducts() throws ParseException, SQLException {
        List<String> dms = dmm.getDownloadManagers(TestInsertUpdate.user1);
        for (String dm : dms) {
            System.out.println("DM : " + dm);
            List<String> dars = dmm.getDataAccessRequestsIDs(dm, null);
            for (String dar : dars) {
                System.out.println("DAR : " + dar);
                List<Download> prods = dmm.getReadyProducts(dar, null);
                for (Download product : prods) {
                    System.out.println("" + product);
                }
            }
        }
    }
    
    public void testGetReadyAccessedDMProducts() throws ParseException, SQLException {
        List<String> dms = dmm.getDownloadManagers(TestInsertUpdate.user1);
//        for (String dm : dms) {
//            System.out.println("DM : " + dm);
            List<String> dars = dmm.getDataAccessRequestsIDs("9709bf64f65d458da07cc15c48663f59", null);
            for (String dar : dars) {
                System.out.println("DAR : " + dar);
                List<Download> prods = dmm.getReadyAccessedProducts(dar, null);
                for (Download product : prods) {
                    System.out.println("" + product);
                }
            }
//        }
    }
    
    public void testGetDMErrors() throws SQLException {
        List<DMMError> dmerrs = dmm.getDMErrors(TestInsertUpdate.dm1);
        for (DMMError dMMError : dmerrs) {
            System.out.println("" + dMMError.getErrorCode() + " - " + dMMError.getErrorMessage() + "\n" + dMMError.getErrorDescription());
        }
    }
    public void testGetDownloadErrors() throws SQLException {
        List<DMMError> dmerrs = dmm.getDownloadErrors("1");
        for (DMMError dMMError : dmerrs) {
            System.out.println("" + dMMError.getErrorCode() + " - " + dMMError.getErrorMessage() + "\n" + dMMError.getErrorDescription());
        }
    }
}
