/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler.downloadmanager;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.Calendar;
import net.eads.astrium.dream.util.DateHandler;
import net.eads.astrium.dream.util.structures.downloadmanager.errors.MonitoringServiceError;
import net.eads.astrium.dream.util.structures.downloadmanager.errors.RegistrationError;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author re-sulrich
 */
public class TestInsertUpdate {
    
    private static DownloadManagerManagementHandler dmm;
    
    public static final String user1 = "f9565cf6dba885cf5e25150f936fd9c1";
    public static final String user2 = "e8fb3edf039b2b2253ea265b200b15e7";
    public static final String dm1 = "5ae3e04b833ef6a49636095fd227dee9";
    public static final String dm2 = "442143e70eddb7768e30f2bc16f024e7";
    //to be replaced with the random IDs created during the creation of the DAR
    public static String dar1 = "25d0587bf7ed8e0ea26f9e5359391cf1";
    public static String dar2 = "ad6807775ea093bf1ea77c7c6adfbcea";
    
    public static Calendar timeFirstDARInsert;
    
    @BeforeClass
    public static void init() { 
        
//        String url = "jdbc:postgresql://10.2.200.247:5432/DownloadManagerDatabase";
                String url = "jdbc:postgresql://192.168.0.20:5432/DownloadManagerDatabase";

        String user = "opensourcedbms";
        String passwd = "opensourcedbms";
        
        dmm = new DownloadManagerManagementHandler(url, user, passwd);
    }
    
    @Test
    public void test() throws SQLException, ParseException, InterruptedException {
//        System.out.println("" + getRandom32BitsID());
        testAddUsers();
        testAddDMs();
        testAddDARs();
        testAddProducts();
        testAddDownloads();
        testAddErrors();
        
//        testUpdateDAR();
//        testUpdateDownload();
//        testSetStatus();
    }
    
    public void testAddUsers() throws SQLException {
        
        dmm.addDMUser(user1, "First user", 5);
        dmm.addDMUser(user2, "Second user", 5);
    }
    
    public void testAddDMs() throws SQLException {
        
        dmm.addNewDownloadManager(dm1, "First Download manager", 30, 300, user1);
        dmm.addNewDownloadManager(dm2, "Second Download manager", 30, 300, user1);
    }
    
    public void testAddDARs() throws SQLException, ParseException {
    
        timeFirstDARInsert = DateHandler.getCalendar(DateHandler.parseDate("2013-08-01"));
        
        Calendar timeSecond = DateHandler.getCalendar(DateHandler.parseDate("2013-08-08"));
        
        dar1 = dmm.addDAR(dm1, null, "1", timeFirstDARInsert.getTime());
        
        dar2 = dmm.addDAR(dm2, null, "1", timeSecond.getTime());
    }
    
    public void  testAddProducts() throws SQLException {
        dmm.addDownloadProduct("http://127.0.0.1:8080/examples/zip/1GB.zip", true, (1024*1024*1024), Calendar.getInstance().getTime());
        dmm.addDownloadProduct("http://127.0.0.1:8080/examples/zip/512MB.zip", true, (512*1024*1024), Calendar.getInstance().getTime());
        
        dmm.addMMFASProduct("http://127.0.0.1:8080/examples/zip/200MB.zip", "1", true, (200*1024*1024), Calendar.getInstance().getTime());
        dmm.addMMFASProduct("http://127.0.0.1:8080/examples/zip/100MB.zip", "1", false, (100*1024*1024), Calendar.getInstance().getTime());
    }
    
    public void testAddDownloads() throws SQLException {
        
        dmm.addNewProductDownload(dar1, "1", null);
        
        dmm.addNewProductDownload(dar2, "3", null);
        dmm.addNewProductDownload(dar2, "4", null);
        
        //For readyAccessed test
        String dl = dmm.addNewProductDownload(dar1, "2", null);
//        dmm.setDownloadingStatusProductDownload(dar1, "2", "The product download has started.", 20);
    }
    
    public void testAddErrors() throws SQLException {
        dmm.setDMError(dm1, new RegistrationError("This download manager is not available for this user."));
//        dmm.setDownloadError("1", new ProductURLServiceError("This download is not available yet."));
    }
    
    public void testSetStatus() throws SQLException {
        dmm.setStatus(dm1, "STOP");
    }
    
    public void testUpdateDAR() throws InterruptedException, SQLException {
        System.out.println("Wait for pause");
//        Thread.sleep(10000);
        dmm.pauseDAR(dar1);
        System.out.println("" + dar1);
//        System.out.println("Wait for cancel");
//        Thread.sleep(10000);
//        dmm.cancelDAR(dar2);
    }
    
    public void testUpdateDownload() throws SQLException {
        dmm.setDownloadingStatusProductDownload(dar1, "1", "message", 20);
        dmm.setDownloadError(dar1, "1", new MonitoringServiceError("error message"));
    }
    
    public static String getRandom32BitsID() {
        
        String id = "";
        
        for (int i = 0; i < 32; i++) {
            
            Double val = Math.random() * 16;
            Double valMod = val/1;
            char x = '0';
            
            if (valMod >= 10) {
                x = (char) ('a' + (valMod - 10));
            }
            else {
                x = (char) ('0' + valMod);
            }
//            System.out.println("" + val + " - " + valMod + " - " + x);
            
            id += x;
        }
        
        return id;
    }
}
