/**
 * --------------------------------------------------------------------------------------------------------
 *   Project                                            :               DREAM
 * --------------------------------------------------------------------------------------------------------
 *   File Name                                          :               MMFASAdminHandler.java
 *   File Type                                          :               Source Code
 *   Description                                        :                *
 * --------------------------------------------------------------------------------------------------------
 *
 * =================================================================
 *             (coffee) COPYRIGHT EADS ASTRIUM LIMITED 2013. All Rights Reserved
 *             This software is supplied by EADS Astrium Limited on the express terms
 *             that it is to be treated as confidential and that it may not be copied,
 *             used or disclosed to others for any purpose except as authorised in
 *             writing by this Company.
 * --------------------------------------------------------------------------------------------------------
 *//*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler.admin;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import net.eads.astrium.dream.dbhandler.DatabaseLoader;

/**
 *
 * @author re-sulrich
 */
public class MMFASAdminHandler extends DatabaseLoader {
    
    public MMFASAdminHandler() {
        super("MMFASDatabase");
    }
    
    public void addMMFAS(String id, String name, String description, String href, String applicationServer) throws SQLException {
        
        String table = "MMFAS";
        
        List<String> fields = new ArrayList<String>();
        fields.add("mmfasId");
        fields.add("name");
        fields.add("description");
        fields.add("href");
        
        fields.add("server");
        
        List<String> gmesmmfas = new ArrayList<String>();
        gmesmmfas.add("'"+id+"'");
        gmesmmfas.add("'"+name+"'");
        gmesmmfas.add("'"+description+"'");
        gmesmmfas.add("'"+href+"'");
        
        gmesmmfas.add("'"+applicationServer+"'");
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(gmesmmfas);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
        
    }
    
    public void addSatellite(String mmfasId, String satelliteId) throws SQLException {
        
        String table = "LNK_MMFAS_Satellite";
        
        List<String> fields = new ArrayList<String>();
      
        fields.add("mmfas");
        fields.add("satellite");
        
        List<String> gmess1 = new ArrayList<String>();
        gmess1.add("'"+mmfasId+"'");
        gmess1.add("'"+satelliteId+"'");
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(gmess1);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
    }
    
}
