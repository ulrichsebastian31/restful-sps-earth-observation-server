/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler.downloadmanager;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import net.eads.astrium.dream.dbhandler.DBOperations;
import net.eads.astrium.dream.dbhandler.DatabaseLoader;
import net.eads.astrium.dream.util.structures.downloadmanager.DMUser;
import net.eads.astrium.dream.util.structures.downloadmanager.DataAccessRequest;
import net.eads.astrium.dream.util.structures.downloadmanager.Download;
import net.eads.astrium.dream.util.structures.downloadmanager.DownloadManager;
import net.eads.astrium.dream.util.structures.downloadmanager.Product;
import net.eads.astrium.dream.util.structures.downloadmanager.errors.DMMError;

/**
 *
 * @author re-sulrich
 */
public class DownloadManagerManagementHandler extends DatabaseLoader {

    private DMUserHandler dmUserHandler;
    private DARHandler darHandler;
    private DownloadManagerHandler downloadManagerHandler;
    private ProductHandler productHandler;
    
    public final void initHandlers() {
        dmUserHandler = new DMUserHandler(this.getDboperations());
        darHandler = new DARHandler(this.getDboperations());
        downloadManagerHandler = new DownloadManagerHandler(this.getDboperations());
        productHandler = new ProductHandler(this.getDboperations());
    }
    
    public DownloadManagerManagementHandler() {
        super("DownloadManagerDatabase");
        initHandlers();
    }

    public DownloadManagerManagementHandler(DBOperations dboperations) {
        super(dboperations);
        initHandlers();
    }

    public DownloadManagerManagementHandler(String databaseURL, String user, String pass) {
        super(databaseURL, user, pass);
        initHandlers();
    }
    
    /**
     * Functions that insert data in the database
     */
    
    public void addDMUser(
            String dmUserID, String dmUserName, int maxDownloadManagers) throws SQLException {
        
        dmUserHandler.addDMUser(dmUserID, dmUserName, maxDownloadManagers);
    }
    
    /**
     * INSERT INTO DownloadManager (downloadManagerID, name, status, refreshPeriod, deconnectionPeriod, lastActivityTime, startTime, user, monitoring)
     * VALUES (<manager.getDatabaseManagerID()>,<manager.getDatabaseManagerName()>,<manager.getStatus()>,<manager.getRefreshPeriod()>,
     * <manager.getDeconnectionPeriod()>,<manager.getLastActivityTime()>,<manager.getStartTime()>,<manager.getUserID()>, <monitoringServiceID>)
     * @param manager 
     */
    public void addDownloadManager(DownloadManager manager) throws SQLException {
        downloadManagerHandler.addDownloadManager(manager);
    }
    /**
     * Adds a newly registered DownloadManager in the system
     * NB : this function is to be used only by the DMRegistrationMgmt function
     * @param id
     * @param name
     * @param refreshPeriod
     * @param deconnectionPeriod
     * @param monitoringServiceID
     * @param userID
     * @throws SQLException 
     */
    public void addNewDownloadManager(String id, String name, int refreshPeriod, int deconnectionPeriod, String userID) throws SQLException {
        
        DownloadManager dm = new DownloadManager(id, name, userID, "CONNECTED", refreshPeriod, deconnectionPeriod, Calendar.getInstance().getTime(), Calendar.getInstance().getTime());
        downloadManagerHandler.addDownloadManager(dm);
    }
    
    public String addNewDAR(String downloadManagerID, String clientIP, String sensorTaskID) throws SQLException {
        return darHandler.addDataAccessRequest(downloadManagerID, clientIP, sensorTaskID, null);
    }
    
    public String addDAR(String downloadManagerID, String clientIP, String sensorTaskID, Date date) throws SQLException {
        return darHandler.addDataAccessRequest(downloadManagerID, clientIP, sensorTaskID, date);
    }
    
    /**
     * UPDATE DownloadManager SET (
     *  DownloadManager.status='ERROR',
     *  DownloadManager.lastActivityTime=<NOW>
     * ) = WHERE downloadManagerID=<downloadManagerID> ;
     * INSERT INTO Error 
     * (errorCode,errorMessage,errorDescription, downloadManager) 
     * VALUES (<error.getErrorCode()>, <error.getErrorMessage()>, <error.getErrorDescription()>, <downloadManagerID>);
     * @param downloadManagerID
     * @param error 
     */
    public void setDMError(String downloadManagerID, DMMError error) throws SQLException {
        downloadManagerHandler.setError(downloadManagerID, error);
    }
    
    /**
     * INSERT INTO Product 
     * (type, mmfasResultID, availibility, nbFiles, size, lastUpdateTime)
     * VALUES('mmfasResult', <mmfasResultID>, <isAvailible>, <nbFiles>, <size>, <lastUpdateTime>)
     * @param product 
     */
    public String addMMFASProduct(String downloadURL, String sensorTaskID, boolean isAvailable, long size, Date lastUpdateTime) throws SQLException {
        return productHandler.addProduct(downloadURL, sensorTaskID, isAvailable, size, lastUpdateTime);
    }
    
    /**
     * INSERT INTO Product 
     * (type, downloadURL, availibility, nbFiles, size, lastUpdateTime)
     * VALUES('download', <downloadURL>, <isAvailible>, <nbFiles>, <size>, <lastUpdateTime>)
     * @param product 
     */
    public String addDownloadProduct(String downloadURL, boolean isAvailable, long size, Date lastUpdateTime) throws SQLException {
        return productHandler.addProduct(downloadURL, null, isAvailable, size, lastUpdateTime);
    }
    
    
    /**
     * UPDATE DownloadManager SET status=<status> WHERE downloadManagerID=<downloadManagerID>
     * @param downloadManagerID
     * @param status
     * @throws SQLException 
     */
    public void setStatus(String downloadManagerID, String status) throws SQLException {
        this.downloadManagerHandler.setStatus(downloadManagerID, status);
    }
    
    public void setSegmentProductsAvailibility(String segmentID, boolean isAvailable) throws SQLException {
        this.productHandler.setSegmentProductsAvailibility(segmentID, isAvailable);
    }
    
    
    
    /**
     * INSERT INTO Download
     * (manager, product, status, percentCompleted, clientIP, lastActivityTime, startTime)
     * VALUES (manager=<downloadManagerID>,product=<productID>,percentCompleted=<percentDownloaded>,clientIP=<clientIP>,lastActivityTime=<NOW>,startTime=<NOW>)
     * @param downloadManagerID
     * @param productID
     * @param clientIP
     * @param status
     * @param percentDownloaded
     * @param lastActivityTime
     * @param startTime
     */
    public String addProductDownload(
            String darID, String productID, 
            Download.ProductDownloadStatus status, String message, int percentDownloaded, 
            Date lastActivityTime, Date startTime) throws SQLException {
        
        return darHandler.addDownload(darID, productID, status, message, percentDownloaded, lastActivityTime, startTime);
    }
    
    public String addNewProductDownload(
            String darID, String productID, 
            String message) throws SQLException {
        
        return darHandler.addNewDownload(darID, productID, message);
    }
    
    /**
     * UPDATE DataAccessRequest SET status='IN_PROGRESS' WHERE darID=<darID>
     * @param darID
     * @throws SQLException 
     */
    public void resumeDAR(String darID) throws SQLException {
        this.darHandler.resumeDAR(darID);
    }
    /**
     * UPDATE DataAccessRequest SET status='PAUSED' WHERE darID=<darID>
     * @param darID
     * @throws SQLException 
     */
    public void pauseDAR(String darID) throws SQLException {
        this.darHandler.pauseDAR(darID);
    }
    
    /**
     * UPDATE DataAccessRequest SET status='CANCELLED' WHERE darID=<darID>
     * @param darID
     * @throws SQLException 
     */
    public void cancelDAR(String darID) throws SQLException {
        this.darHandler.cancelDAR(darID);
    }
    
    /**
     * UPDATE Product SET availibility=<isAvailable> WHERE productID = <productID>
     * @param productID
     * @param isAvailable
     * @throws SQLException 
     */
    public void setProductAvailibility(String productID, boolean isAvailable) throws SQLException, ParseException {
        
        this.productHandler.setProductAvailibility(productID, isAvailable);
    }
    
    
    
    
    /**
     * UPDATE Download SET (percentCompleted=<percentDownloaded>,clientIP=<clientIP>,lastActivityTime=<NOW>) 
     * WHERE downloadID=<downloadID>
     * @param downloadID
     * @param percentDownloaded
     * @param clientIP          ignored if null
     */
    public void setDownloadingStatusProductDownload(
            String downloadID, 
            String message, int percentDownloaded) throws SQLException {
        
        darHandler.updateDownload(downloadID, Download.ProductDownloadStatus.DOWNLOADING, message, percentDownloaded);
    }
    
    /**
     * UPDATE Download SET (percentCompleted=<percentDownloaded>,clientIP=<clientIP>,lastActivityTime=<NOW>) 
     * WHERE darID=<darID> AND productID=<productID>
     * @param darID
     * @param productID
     * @param percentDownloaded
     * @param clientIP          ignored if null
     */
    public void setDownloadingStatusProductDownload(
            String darID, String productID, 
            String message, int percentDownloaded) throws SQLException {
        
        darHandler.updateDownload(darID, productID, Download.ProductDownloadStatus.DOWNLOADING, message, percentDownloaded);
    }
    
    /**
     * UPDATE Download SET (
     *  status='COMPLETED',
     *  percentCompleted=100,
     *  clientIP=<clientIP>,          ignored if null
     *  lastActivityTime=<NOW>,
     *  endTime=<NOW>
     * ) = WHERE downloadID=<downloadID>
     * @param downloadID
     * @param percentDownloaded
     * @param clientIP 
     */
    public void setCompletedStatusProductDownload(
            String downloadID, String message) throws SQLException {
        
        darHandler.updateDownload(downloadID, Download.ProductDownloadStatus.COMPLETED, message, 100);
    }
    
    /**
     * UPDATE Download SET (
     *  status='COMPLETED',
     *  percentCompleted=100,
     *  clientIP=<clientIP>,          ignored if null
     *  lastActivityTime=<NOW>,
     *  endTime=<NOW>
     * WHERE darID=<darID> AND productID=<productID>
     * @param downloadID
     * @param percentDownloaded
     * @param clientIP 
     */
    public void setCompletedStatusProductDownload(
            String darID, String productID, String message) throws SQLException {
        
        darHandler.updateDownload(darID, productID, Download.ProductDownloadStatus.COMPLETED, message, 100);
    }
    
    
    
    /**
     * UPDATE Download SET (percentCompleted=<percentDownloaded>,clientIP=<clientIP>,lastActivityTime=<NOW>) = WHERE downloadID=<downloadID>
     * @param downloadID
     * @param percentDownloaded
     * @param clientIP          ignored if null
     */
    public void setNotStartedStatusProductDownload(
            String downloadID, 
            String message) throws SQLException {
        
        darHandler.updateDownload(downloadID, Download.ProductDownloadStatus.NOT_STARTED, message, 0);
    }
    
    /**
     * UPDATE Download SET (percentCompleted=<percentDownloaded>,clientIP=<clientIP>,lastActivityTime=<NOW>) = WHERE darID=<darID> AND productID=<productID>
     * @param downloadID
     * @param percentDownloaded
     * @param clientIP          ignored if null
     */
    public void setNotStartedStatusProductDownload(
            String darID, String productID, 
            String message) throws SQLException {
        
        darHandler.updateDownload(darID, productID, Download.ProductDownloadStatus.NOT_STARTED, message, 0);
    }
    
    
    
    /**
     * UPDATE Download SET (
     *  Download.status='ERROR',
     *  Download.lastActivityTime=<NOW>,
     *  Download.endTime=<NOW>
     * ) = WHERE downloadID=<downloadID> ;
     * INSERT INTO Error 
     * (errorCode,errorMessage,errorDescription, download) 
     * VALUES (<error.getErrorCode()>, <error.getErrorMessage()>, <error.getErrorDescription()>, <downloadID>);
     * @param downloadID
     * @param error
     */
    public void setDownloadError(String downloadID, DMMError error) throws SQLException {
        
        darHandler.setError(downloadID, error);
    }
    
    /**
     * UPDATE Download SET (
     *  Download.status='ERROR',
     *  Download.lastActivityTime=<NOW>,
     *  Download.endTime=<NOW>
     * ) = WHERE darID=<darID> AND productID=<productID> ;
     * INSERT INTO Error 
     * (errorCode,errorMessage,errorDescription, download) 
     * VALUES (<error.getErrorCode()>, <error.getErrorMessage()>, <error.getErrorDescription()>, SELECT downloadID WHERE darID=<darID> AND productID=<productID>);
     * @param darID
     * @param productID
     * @param error
     */
    public void setDownloadError(String darID, String productID, DMMError error) throws SQLException {
        
        darHandler.setError(darID, productID, error);
    }
    
    /**
     * Functions that read (SELECT) data from the database
     */
    
    public DMUser getUser(String userID) throws SQLException {
        return this.dmUserHandler.getDMUser(userID);
    }
    
    /**
     * SELECT COUNT(*) FROM DownloadManager WHERE DownloadManagerID = <downloadManagerID>
     * @param downloadManagerID
     * @return 
     */
    public boolean isDownloadManagerRegistered(String downloadManagerID) throws SQLException {
        
        return this.downloadManagerHandler.isDownloadManagerRegistered(downloadManagerID);
    }
    
    /**
     * SELECT * FROM DownloadManager WHERE downloadManagerID=<downloadManagerID>
     * @param downloadManagerID
     * @return 
     */
    public DownloadManager getDownloadManager(String downloadManagerID) throws ParseException, SQLException {
        return this.downloadManagerHandler.getDownloadManager(downloadManagerID);
    }
    
    /**
     * SELECT * FROM DataAccessRequest WHERE darID=<darID>
     * @param darID
     * @return 
     */
    public DataAccessRequest getDAR(String darID) throws SQLException {
        return this.darHandler.getDAR(darID);
    }
    
    /**
     * SELECT * FROM DataAccessRequest WHERE sensorTaskID=<sensorTaskID>
     * @param sensorTaskID
     * @return 
     */
    public DataAccessRequest getSensorTaskDAR(String sensorTaskID) throws SQLException {
        return this.darHandler.getSensorTaskDAR(sensorTaskID);
    }
    
    public DataAccessRequest getSensorTaskDARWithDownloads(String sensorTaskID) throws SQLException, ParseException {
        return this.darHandler.getSensorTaskDARWithDownloads(sensorTaskID);
    }
    
    public DataAccessRequest getSensorTaskDARWithReadyDownloads(String sensorTaskID) throws SQLException, ParseException {
        return this.darHandler.getSensorTaskDARWithReadyDownloads(sensorTaskID);
    }
    
    /**
     * SELECT status FROM DownloadManager WHERE downloadManagerID=<downloadManagerID>
     * @param downloadManagerID
     * @return 
     */
    public String getStatus(String downloadManagerID) throws SQLException {
        return this.downloadManagerHandler.getStatus(downloadManagerID);
    }
    
    /**
     * SELECT refreshTime FROM DownloadManager WHERE downloadManagerID=<downloadManagerID>
     * @param downloadManagerID
     * @return
     * @throws ParseException
     * @throws SQLException 
     */
    public int getDownloadManagerRefreshTime(String downloadManagerID) throws ParseException, SQLException {
        return this.downloadManagerHandler.getDownloadManagerRefreshTime(downloadManagerID);
    }
    
    /**
     * SELECT * FROM Product WHERE productID=<productID>
     * @param productID
     * @return 
     */
    public Product getProduct(String productID) throws ParseException, SQLException {
        return this.productHandler.getProduct(productID);
    }
    
    public String getProductID(String url) throws SQLException {
        return this.productHandler.getProductID(url);
    }
    
    /**
     * SELECT productID FROM Product WHERE mmfasSegmentID=<mmfasSegmentID>
     * @param mmfasSegmentID
     * @return 
     */
    public List<Product> getSegmentProducts(String mmfasSegmentID) throws SQLException, ParseException {
        return this.productHandler.getSegmentProducts(mmfasSegmentID);
    }
    
    /**
     * SELECT downloadManagerID FROM DownloadManager WHERE user=<userID>
     * @param userID
     * @return 
     */
    public List<String> getDownloadManagers(String userID) throws SQLException {
        return this.dmUserHandler.getDownloadManagersIDs(userID);
    }
    /**
     * SELECT COUNT(*) FROM DownloadManager WHERE userId = <userId>
     * @param userID
     * @return 
     */
    public int getUserNbDownloadManagers(String userID) throws SQLException {
        return this.dmUserHandler.getNbDownloadManagers(userID);
    }
    /**
     * SELECT MaxDownloadManagers FROM User WHERE userId = <userId>
     * @param userID
     * @return 
     */
    public int getUserMaxDownloadManagers(String userID) throws SQLException {
        return this.dmUserHandler.getMaxDownloadManagers(userID);
    }
    
    public List<String> getDataAccessRequestsIDs(String downloadManagerID, Date setTime) throws ParseException, SQLException {
        return this.downloadManagerHandler.getDataAccessRequestsIDs(downloadManagerID, setTime);
    }
    
    
    /**
     * SELECT (DISTINCT productID), * FROM Product
     * WHERE productID IN (
     *  SELECT product FROM Download WHERE manager=<downloadManagerID>
     * );
     * @param downloadManagerID
     * @return 
     */
    public List<Download> getProducts(String darID, Date setTime) throws ParseException, SQLException {
        return this.darHandler.getProducts(darID, setTime);
    }
    
    /**
     * SELECT (DISTINCT productID), * FROM Product
     * WHERE productID IN (
     *  SELECT product FROM Download WHERE manager=<downloadManagerID>
     * )
     * AND availibility='TRUE';
     * @param downloadManagerID
     * @return 
     */
    public List<Download> getReadyProducts(String darID, Date setTime) throws SQLException, ParseException {
        return this.darHandler.getReadyProducts(darID, setTime);
    }
    
    public List<Download> getReadyAccessedProducts(String darID, Date setTime) throws SQLException, ParseException {
        return this.darHandler.getReadyAccessedProducts(darID, setTime);
    }
    
    /**
     * SELECT * FROM Error
     * WHERE (
     *  downloadManager=<downloadManagerID>
     * OR
     *  download IN (SELECT downloadID FROM DownloadDownload WHERE manager=<downloadManagerID>)
     * )
     * @param manager
     * @return 
     */
    public List<DMMError> getDMErrors(String downloadManagerID) throws SQLException {
        return this.downloadManagerHandler.getErrors(downloadManagerID);
    }
    
    /**
     * SELECT * FROM Error
     * WHERE download=<downloadID>
     * @param downloadManagerID     If null, then ignored
     * @param downloadID
     * @return 
     */
    public List<DMMError> getDownloadErrors(String downloadID) throws SQLException {
        return this.darHandler.getErrors(downloadID);
    }
}
