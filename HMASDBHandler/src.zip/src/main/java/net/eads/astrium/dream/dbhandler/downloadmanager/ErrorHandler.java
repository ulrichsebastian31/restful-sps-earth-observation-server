/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler.downloadmanager;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import net.eads.astrium.dream.dbhandler.DBOperations;
import net.eads.astrium.dream.dbhandler.DatabaseLoader;
import net.eads.astrium.dream.util.structures.downloadmanager.errors.AuthorizationError;
import net.eads.astrium.dream.util.structures.downloadmanager.errors.DMMError;
import net.eads.astrium.dream.util.structures.downloadmanager.errors.MonitoringServiceError;
import net.eads.astrium.dream.util.structures.downloadmanager.errors.ProductURLServiceError;
import net.eads.astrium.dream.util.structures.downloadmanager.errors.RegistrationError;

/**
 *
 * @author re-sulrich
 */
public class ErrorHandler extends DatabaseLoader {

    public ErrorHandler() {
        super("DownloadManagerDatabase");
    }

    public ErrorHandler(DBOperations dboperations) {
        super(dboperations);
    }

    public ErrorHandler(String databaseURL, String user, String pass) {
        super(databaseURL, user, pass);
    }
    
    /**
     * Adds a new error to the database, sets the foreign key, and sends back the errorID
     * @param isDownloadManagerError
     * @param id
     * @param error
     * @return 
     */
    public String addError(boolean isDownloadManagerError, String id, DMMError error) throws SQLException {
        
        String errorID = null;
        
        String table = "Error";

        List<String> fields = new ArrayList<String>();

        fields.add("errorCode");
        fields.add("errorMessage");
        fields.add("errorDescription");
        //Foreign keys
        if (isDownloadManagerError) {
            fields.add("downloadmanager");
        }
        else {
            fields.add("download");
        }

        List<String> depl1 = new ArrayList<String>();
        depl1.add("" + error.getErrorCode());
        depl1.add("'" + error.getErrorMessage() + "'");
        depl1.add("'" + error.getErrorDescription() + "'");
        //Foreign key
        depl1.add("'" + id + "'");

        List<List<String>> values = new ArrayList<List<String>>();
        values.add(depl1);

        errorID = this.getDboperations().insertReturningId(
                table,
                fields,
                values,
                "errorID");

        return errorID;
    }
    
    
    public List<DMMError> getErrors(boolean isDownloadManagerError, String id) throws SQLException {
        
        List<DMMError> errors = new ArrayList<>();
        
        String table = "Error";

        List<String> fields = new ArrayList<String>();

        fields.add("errorCode");
        fields.add("errorMessage");
        fields.add("errorDescription");
        
        List<String> conditions = new ArrayList<String>();
        if (isDownloadManagerError)
            conditions.add("downloadmanager='"+id+"'");
        else
            conditions.add("download='"+id+"'");
        
        List<List<String>> result = select(fields, table, conditions);
        
        if (result != null && result.size() > 0) {
            for (List<String> list : result) {
                String mess = list.get(1);
                switch (mess.toLowerCase()) {
                    case "authorization error":
                        errors.add(new AuthorizationError(list.get(2)));
                    break;
                    case "monitoring service error":
                        errors.add(new MonitoringServiceError(list.get(2)));
                        
                    break;
                    case "product url service error":
                        errors.add(new ProductURLServiceError(list.get(2)));
                        
                    break;
                    case "registration error":
                        errors.add(new RegistrationError(list.get(2)));
                        
                    break;
                    default:
                        errors.add(new DMMError(Integer.valueOf(list.get(0)), list.get(1), list.get(2)));
                    break;
                                
                }
                
            }
        }
        
        return errors;
    }
    
}
