/**
 * --------------------------------------------------------------------------------------------------------
 *   Project                                            :               DREAM
 * --------------------------------------------------------------------------------------------------------
 *   File Name                                          :               DeploymentAdminHandler.java
 *   File Type                                          :               Source Code
 *   Description                                        :                *
 * --------------------------------------------------------------------------------------------------------
 *
 * =================================================================
 *             (coffee) COPYRIGHT EADS ASTRIUM LIMITED 2013. All Rights Reserved
 *             This software is supplied by EADS Astrium Limited on the express terms
 *             that it is to be treated as confidential and that it may not be copied,
 *             used or disclosed to others for any purpose except as authorised in
 *             writing by this Company.
 * --------------------------------------------------------------------------------------------------------
 *//*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler.admin;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.eads.astrium.dream.dbhandler.DatabaseLoader;

/**
 *
 * @author re-sulrich
 */
public class DeploymentAdminHandler extends DatabaseLoader {

    public DeploymentAdminHandler() {
        super("MMFASDatabase");
    }
    
    public void addApplicationServer(String name,String description,String serverBaseAddress) throws SQLException {
        
        String table = "ApplicationServer";
        
        List<String> fields = new ArrayList<String>();
        
        fields.add("name");
        fields.add("description");
        fields.add("serverBaseAddress");
        
        List<String> depl1 = new ArrayList<String>();
        fields.add(name);
        fields.add(description);
        fields.add(serverBaseAddress);
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(depl1);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
    }
    
    public void changeMMFASDeployment(String mmfasId, String applicationServerId) throws SQLException {
        
        String table = "MMFAS";
        List<String> fields = Arrays.asList(new String[]{"server"}); 
        List<String> values = Arrays.asList(new String[]{applicationServerId}); 
        String idColumn = "mmfasId"; 
        String idColumnValue = mmfasId;
        
        this.getDboperations().update(table, fields, values, idColumn + "=" + idColumnValue);
    }
    
    public void changeFASDeployment(String fasId, String applicationServerId) throws SQLException {
        
        String table = "FAS";
        List<String> fields = Arrays.asList(new String[]{"server"}); 
        List<String> values = Arrays.asList(new String[]{applicationServerId}); 
        String idColumn = "fasId"; 
        String idColumnValue = fasId;
        
        this.getDboperations().update(table, fields, values, idColumn + "=" + idColumnValue);
    }
    
    public void changeMissionPlannerDeployment(String mpId, String applicationServerId) throws SQLException {
        
        String table = "MissionPlanner";
        List<String> fields = Arrays.asList(new String[]{"server"}); 
        List<String> values = Arrays.asList(new String[]{applicationServerId}); 
        String idColumn = "mpId"; 
        String idColumnValue = mpId;
        
        this.getDboperations().update(table, fields, values, idColumn + "=" + idColumnValue);
    }
}
