/**
 * --------------------------------------------------------------------------------------------------------
 *   Project                                            :               DREAM
 * --------------------------------------------------------------------------------------------------------
 *   File Name                                          :               ApplicationServerLoader.java
 *   File Type                                          :               Source Code
 *   Description                                        :                *
 * --------------------------------------------------------------------------------------------------------
 *
 * =================================================================
 *             (coffee) COPYRIGHT EADS ASTRIUM LIMITED 2013. All Rights Reserved
 *             This software is supplied by EADS Astrium Limited on the express terms
 *             that it is to be treated as confidential and that it may not be copied,
 *             used or disclosed to others for any purpose except as authorised in
 *             writing by this Company.
 * --------------------------------------------------------------------------------------------------------
 *//*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author re-sulrich
 */
public class ApplicationServerLoader extends DatabaseLoader {

    public static final String DREAM_WS_CONF_FOLDER =
            System.getProperty("user.home") + File.separator + ".dream" + File.separator;
    private final String applicationServerId;

    public String getApplicationServerId() {
        return applicationServerId;
    }

    public ApplicationServerLoader(
            String applicationServerId) {

        super("MMFASDatabase");
        this.applicationServerId = applicationServerId;
    }

    public ApplicationServerLoader(String applicationServerId, DBOperations dboperations) {
        
        super(dboperations);
        this.applicationServerId = applicationServerId;
    }
    
    public ApplicationServerLoader(
            String applicationServerId, 
            String databaseURL, String user, String pass) {
        
        super(databaseURL, user, pass);
        
        this.applicationServerId = applicationServerId;
    }
    
    public List<String> getMMFASIds() throws SQLException {

        
        
        
        System.out.println("");
        System.out.println("App server ID : " + getApplicationServerId());
        System.out.println("");
        
        
        List<String> mmfasIds = new ArrayList<String>();

        List<String> fields = new ArrayList<String>();
        fields.add("mmfasId");

        String table = "MMFAS";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("server='" + applicationServerId + "'");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        for (List<String> entry : result) {

            mmfasIds.add(entry.get(0));
        }

        return mmfasIds;

    }

    public List<String> getMissionPlannersIds() throws SQLException {

        System.out.println("");
        System.out.println("App server ID : " + getApplicationServerId());
        System.out.println("");
        
        
        List<String> mpIds = new ArrayList<String>();

        List<String> fields = new ArrayList<String>();
        fields.add("mpId");

        String table = "MissionPlanner";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("server='" + applicationServerId + "'");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        for (List<String> entry : result) {

            mpIds.add(entry.get(0));
        }

        return mpIds;

    }

    public String getServerBaseURI() throws SQLException {

        String serverBaseURI = null;

        List<String> fields = new ArrayList<String>();
        fields.add("serverbaseaddress");

        String table = "ApplicationServer";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("asId='" + applicationServerId + "'");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.get(0) != null) {
            serverBaseURI = result.get(0).get(0);
        }

        return serverBaseURI;
    }

//    public void createMMFASConfigurationFileFolder() throws SQLException {
//
//        Path confFolderBasePath = Paths.get(ApplicationServerLoader.DREAM_WS_CONF_FOLDER);
//
//
//    }
}
