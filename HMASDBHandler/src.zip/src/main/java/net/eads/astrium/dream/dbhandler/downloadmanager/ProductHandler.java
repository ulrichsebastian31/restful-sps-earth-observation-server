/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler.downloadmanager;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import net.eads.astrium.dream.dbhandler.DBOperations;
import net.eads.astrium.dream.dbhandler.DatabaseLoader;
import net.eads.astrium.dream.util.DateHandler;
import net.eads.astrium.dream.util.structures.downloadmanager.Download;
import net.eads.astrium.dream.util.structures.downloadmanager.Product;

/**
 *
 * @author re-sulrich
 */
public class ProductHandler extends DatabaseLoader {

    public ProductHandler() {
        super("DownloadManagerDatabase");
    }

    public ProductHandler(DBOperations dboperations) {
        super(dboperations);
    }

    public ProductHandler(String databaseURL, String user, String pass) {
        super(databaseURL, user, pass);
    }
    
    public String addProduct(String downloadURL, String mmfasSegmentID, boolean isAvailable, long size, Date lastUpdateTime) throws SQLException {
        
        String productID = null;
        
        String table = "Product";

        List<String> fields = new ArrayList<String>();

        fields.add("downloadURL");
        fields.add("availibility");
        fields.add("size");
        fields.add("lastUpdateTime");

        List<String> depl1 = new ArrayList<String>();
        depl1.add("'" + downloadURL + "'");
        depl1.add("'" + isAvailable + "'");
        depl1.add("'" + size + "'");
        depl1.add("'" + DateHandler.formatDate(lastUpdateTime) + "'");

        if (mmfasSegmentID != null && !mmfasSegmentID.equals("")) {
            
            fields.add("mmfasSegmentID");
            depl1.add("'" + mmfasSegmentID + "'");
        }

        List<List<String>> values = new ArrayList<List<String>>();
        values.add(depl1);

        productID = this.getDboperations().insertReturningId(
                table,
                fields,
                values,
                "productID");

        return productID;
    }
    
    /**
     * UPDATE Product SET availibility=<isAvailable> WHERE productID = <productID>
     * @param productID
     * @param isAvailable
     * @throws SQLException 
     */
    public void setProductAvailibility(String productID, boolean isAvailable) throws SQLException, ParseException {
        
        String table = "Product";
        
        List<String> fields = new ArrayList<>();
        fields.add("availibility");
        fields.add("lastUpdateTime");
        
        List<String> values = new ArrayList<>();
        values.add("'" + isAvailable + "'");
        values.add("'" + DateHandler.formatDate(Calendar.getInstance().getTime()) + "'");
        
        String condition = "productID='" +productID+ "'";
        
        this.getDboperations().update(table, fields, values, condition);
    }
    
    
    public void setSegmentProductsAvailibility(String segmentID, boolean isAvailable) throws SQLException {
        
        String table = "Product";
        
        List<String> fields = new ArrayList<>();
        fields.add("availibility");
        fields.add("lastUpdateTime");
        
        List<String> values = new ArrayList<>();
        values.add("'" + isAvailable + "'");
        values.add("'" + DateHandler.formatDate(Calendar.getInstance().getTime()) + "'");
        
        String condition = "mmfasSegmentID='" +segmentID+ "'";
        
        this.getDboperations().update(table, fields, values, condition);
    }
    
    /*
     * Reading from the database
     */
    
    public Product getProduct(String productID) throws ParseException, SQLException {
        
        Product prod = null;
        
        List<String> fields = new ArrayList<String>();
        fields.add("mmfasSegmentID");
        fields.add("downloadURL");
        fields.add("availibility");
        fields.add("lastUpdateTime");
        fields.add("size");

        String table = "Product";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("productID='" + productID + "'");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            
            prod = new Product(
                    productID, 
                    result.get(0).get(0),                               //mmfasResultID
                    result.get(0).get(1),                               //downloadURL
                    result.get(0).get(2).equalsIgnoreCase("true"),      //IsAvailable
                    DateHandler.parseBDDDate(result.get(0).get(3)),    //lastUpdateTime
                    Long.valueOf(result.get(0).get(4)));                 //size
        }
        
        return prod;
    }
    
    public String getProductID(String url) throws SQLException {
        
        String productID = null;
        
        List<String> fields = new ArrayList<String>();
        fields.add("productID");
        
        String table = "Product";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("downloadURL='" + url + "'");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            productID = result.get(0).get(0);
        }
        
        return productID;
    }
    
    public List<String> getDownloads(String productID) throws SQLException {
        
        List<String> downs = new ArrayList<>();
        
        List<String> fields = new ArrayList<String>();
        fields.add("downloadID");

        String table = "Download";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("product='" + productID + "'");
        
        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            for (List<String> list : result) {
                downs.add(list.get(0));
            }
        }
        
        return downs;
    }
    
    public List<Product> getSegmentProducts(String mmfasSegmentID) throws SQLException, ParseException {
        
        List<Product> prods = new ArrayList<>();
        
        List<String> fields = new ArrayList<String>();
        fields.add("productID");
        fields.add("mmfasSegmentID");
        fields.add("downloadURL");
        fields.add("availibility");
        fields.add("lastUpdateTime");
        fields.add("size");
        
        String table = "Product";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("mmfasSegmentID='" + mmfasSegmentID + "'");
        
        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            for (List<String> list : result) {
                prods.add(new Product(
                    list.get(0), 
                    list.get(1),                               //mmfasSegmentID
                    list.get(2),                               //downloadURL
                    list.get(3).equalsIgnoreCase("true"),      //IsAvailable
                    DateHandler.parseBDDDate(list.get(4)),    //lastUpdateTime
                    Long.valueOf(list.get(5))));                 //size);
            }
        }
        
        return prods;        
    }
}
