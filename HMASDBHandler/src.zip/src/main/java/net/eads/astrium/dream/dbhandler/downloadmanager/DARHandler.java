/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler.downloadmanager;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.eads.astrium.dream.dbhandler.DBOperations;
import net.eads.astrium.dream.dbhandler.DatabaseLoader;
import net.eads.astrium.dream.util.Algorithms;
import net.eads.astrium.dream.util.DateHandler;
import net.eads.astrium.dream.util.structures.downloadmanager.DataAccessRequest;
import net.eads.astrium.dream.util.structures.downloadmanager.Download;
import net.eads.astrium.dream.util.structures.downloadmanager.Product;
import net.eads.astrium.dream.util.structures.downloadmanager.errors.DMMError;

/**
 *
 * @author re-sulrich
 */
public class DARHandler extends DatabaseLoader {

    private ProductHandler productHandler;
    private ErrorHandler errorHandler;
    
    public DARHandler() {
        super("DownloadManagerDatabase");
        errorHandler = new ErrorHandler(this.getDboperations());
        productHandler = new ProductHandler(this.getDboperations());
    }

    public DARHandler(DBOperations dboperations) {
        super(dboperations);
        errorHandler = new ErrorHandler(this.getDboperations());
        productHandler = new ProductHandler(this.getDboperations());
    }

    public DARHandler(String databaseURL, String user, String pass) {
        super(databaseURL, user, pass);
        errorHandler = new ErrorHandler(this.getDboperations());
        productHandler = new ProductHandler(this.getDboperations());
    }
    
    
    
    
    /*
     * Insert into database
     */
    
    private String getNewDataAccessRequestID() throws SQLException {
        
        String darID = null;
        boolean exists = true;
        
        while (exists) {
            darID = Algorithms.getRandom32BitsID();
            exists = false;
            
            String table = "DataAccessRequest";

            List<String> fields = new ArrayList<String>();
            fields.add("darID");

            List<String> conditions = new ArrayList<String>();
            conditions.add("darID='" + darID + "'");

            List<List<String>> result = select(fields, table, conditions);
            if (result != null && result.size() > 0) {
                exists = true;
            }
        }
        return darID;
    }
    
    public String addDataAccessRequest (
            String downloadManagerID, String clientIP, String sensorTaskID, Date creationTime) throws SQLException {
        
        String table = "DataAccessRequest";
        
        String darID = this.getNewDataAccessRequestID();
        if (creationTime == null) {
            creationTime = Calendar.getInstance().getTime();
        }
        
        List<String> fields = new ArrayList<String>();

        fields.add("darID");
        fields.add("creationTime");
        fields.add("status");
        fields.add("manager");

        List<String> depl1 = new ArrayList<String>();
        depl1.add("'" + darID + "'");
        depl1.add("'" + DateHandler.formatDate(creationTime) + "'");
        depl1.add("'IN_PROGRESS'");
        depl1.add("'" + downloadManagerID + "'");
        
        if (clientIP != null && !clientIP.equals("")) {
            
            fields.add("clientIP");
            depl1.add("'" + clientIP + "'");
        }
        if (sensorTaskID != null && !sensorTaskID.equals("")) {
            
            fields.add("sensorTaskID");
            depl1.add("'" + sensorTaskID + "'");
        }
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(depl1);

        this.getDboperations().insert(
                table,
                fields,
                values);
        
        return darID;
    }
    
    /**
     * INSERT INTO Download
     * (manager, product, status, percentCompleted, clientIP, lastActivityTime, startTime)
     * VALUES (manager=<downloadManagerID>,product=<productID>,percentCompleted=<percentDownloaded>,clientIP=<clientIP>,lastActivityTime=<NOW>,startTime=<NOW>)
     * @param darID
     * @param productID
     * @param clientIP
     * @param status
     * @param percentDownloaded
     * @param lastActivityTime
     * @param startTime
     */
    public String addDownload(
            String darID, String productID, 
            Download.ProductDownloadStatus status, String message, int percentDownloaded, 
            Date lastActivityTime, Date startTime) throws SQLException {
        
        String downloadID = null;
        
        String table = "Download";

        List<String> fields = new ArrayList<String>();

        fields.add("status");
        fields.add("message");
        fields.add("percentCompleted");
        fields.add("lastActivityTime");
        fields.add("startTime");

        //Foreign keys
        fields.add("dar");
        fields.add("product");

        List<String> depl1 = new ArrayList<String>();
        depl1.add("'" + status + "'");
        depl1.add("'" + message + "'");
        depl1.add("" + percentDownloaded);
        depl1.add("'" + DateHandler.formatDate(lastActivityTime) + "'");
        depl1.add("'" + DateHandler.formatDate(startTime) + "'");

        //Foreign keys
        depl1.add("'" + darID + "'");
        depl1.add("'" + productID + "'");

        List<List<String>> values = new ArrayList<List<String>>();
        values.add(depl1);

        downloadID = this.getDboperations().insertReturningId(
                table,
                fields,
                values,
                "downloadID");

        return downloadID;
    }
    
    
    public String addNewDownload(
            String darID, String productID, 
            String message) throws SQLException {
        
        return this.addDownload(darID, productID,
                Download.ProductDownloadStatus.NOT_STARTED, message, 0, 
                Calendar.getInstance().getTime(), Calendar.getInstance().getTime());
    }
    
    /**
     * UPDATE DataAccessRequest SET status='IN_PROGRESS' WHERE darID=<darID>
     * @param darID
     * @throws SQLException 
     */
    public void resumeDAR(String darID) throws SQLException {
        
        String table = "DataAccessRequest";
        
        List<String> fields = new ArrayList<>();
        fields.add("status");
        
        List<String> values = new ArrayList<>();
        values.add("'IN_PROGRESS'");
        
        String condition = "darID='" +darID+ "'";
        
        this.getDboperations().update(table, fields, values, condition);
    }
    
    /**
     * UPDATE DataAccessRequest SET status='PAUSED' WHERE darID=<darID>
     * @param darID
     * @throws SQLException 
     */
    public void pauseDAR(String darID) throws SQLException {
        
        String table = "DataAccessRequest";
        
        List<String> fields = new ArrayList<>();
        fields.add("status");
        fields.add("status");
        
        List<String> values = new ArrayList<>();
        values.add("'PAUSED'");
        
        String condition = "darID='" +darID+ "'";
        
        this.getDboperations().update(table, fields, values, condition);
    }
    
    /**
     * UPDATE DataAccessRequest SET status='CANCELLED' WHERE darID=<darID>
     * @param darID
     * @throws SQLException 
     */
    public void cancelDAR(String darID) throws SQLException {
        
        String table = "DataAccessRequest";
        
        List<String> fields = new ArrayList<>();
        fields.add("status");
        
        List<String> values = new ArrayList<>();
        values.add("'CANCELLED'");
        
        String condition = "darID='" +darID+ "'";
        
        this.getDboperations().update(table, fields, values, condition);
    }
    
    /**
     * UPDATE Download SET (
     *  status=<status>,
     *  percentCompleted=<percentDownloaded>,
     *  clientIP=<clientIP>,
     *  lastActivityTime=<NOW>,
     *  endTime=<NOW>
     * ) = WHERE downloadID=<downloadID>
     * @param downloadID
     * @param percentDownloaded
     */
    public void updateDownload(
            String downloadID, 
            Download.ProductDownloadStatus status, String message,
            int percentCompleted) throws SQLException {
        
        String table = "Download";
        
        List<String> fields = new ArrayList<>();
        fields.add("status");
        fields.add("message");
        fields.add("percentCompleted");
        fields.add("lastActivityTime");
        
        List<String> values = new ArrayList<>();
        values.add("'" + status + "'");
        values.add("'" + message + "'");
        values.add("" + percentCompleted);
        values.add("'" + DateHandler.formatDate(Calendar.getInstance().getTime()) + "'");
        
        if (status.equals(Download.ProductDownloadStatus.COMPLETED)) {
            fields.add("endTime");
            values.add("'" + DateHandler.formatDate(Calendar.getInstance().getTime()) + "'");
        }
        
        String condition = "downloadID='" +downloadID+ "'";
        
        this.getDboperations().update(table, fields, values, condition);
    }
    
    /**
     * UPDATE Download SET (
     *  status=<status>,
     *  percentCompleted=<percentDownloaded>,
     *  lastActivityTime=<NOW>,
     *  endTime=<NOW>
     * ) = WHERE darID=<darID> AND productID=<productID>
     * @param downloadID
     * @param percentDownloaded
     * @return downloadID
     */
    public String updateDownload(
            String darID, String productID, 
            Download.ProductDownloadStatus status, String message,
            int percentCompleted) throws SQLException {
        
        String downloadID = null;
        
        String table = "Download";
        
        List<String> fields = new ArrayList<>();
        fields.add("status");
        fields.add("message");
        fields.add("percentCompleted");
        fields.add("lastActivityTime");
        
        List<String> values = new ArrayList<>();
        values.add("'" + status + "'");
        values.add("'" + message + "'");
        values.add("" + percentCompleted);
        values.add("'" + DateHandler.formatDate(Calendar.getInstance().getTime()) + "'");
        
        if (status.equals(Download.ProductDownloadStatus.COMPLETED)) {
            fields.add("endTime");
            values.add("'" + DateHandler.formatDate(Calendar.getInstance().getTime()) + "'");
        }
        
        String condition = "dar='" +darID+ "' AND product='" +productID+ "'";
        
        downloadID = this.getDboperations().update(table, fields, values, condition, "downloadID");
        
        return downloadID;
    }
    
    
    /**
     * UPDATE Download SET (
     *  status=<status>,
     *  percentCompleted=<percentDownloaded>,
     *  clientIP=<clientIP>,
     *  lastActivityTime=<NOW>,
     *  endTime=<NOW>
     * ) = WHERE downloadID=<downloadID>
     * @param downloadID
     * @param percentDownloaded
     */
    public void updateDownloadLastActivityTime(
            String downloadID) throws SQLException {
        
        String table = "Download";
        
        List<String> fields = new ArrayList<>();
        fields.add("lastActivityTime");
        
        List<String> values = new ArrayList<>();
        values.add("'" + DateHandler.formatDate(Calendar.getInstance().getTime()) + "'");
        
        String condition = "downloadID='" +downloadID+ "'";
        
        this.getDboperations().update(table, fields, values, condition);
    }
    
    /**
     * UPDATE Download SET (
     *  status=<status>,
     *  percentCompleted=<percentDownloaded>,
     *  lastActivityTime=<NOW>,
     *  endTime=<NOW>
     * ) = WHERE darID=<darID> AND productID=<productID>
     * @param downloadID
     * @param percentDownloaded
     * @return downloadID
     */
    public String updateDownloadLastActivityTime(
            String darID, String productID) throws SQLException {
        
        String downloadID = null;
        
        String table = "Download";
        
        List<String> fields = new ArrayList<>();
        fields.add("lastActivityTime");
        
        List<String> values = new ArrayList<>();
        values.add("'" + DateHandler.formatDate(Calendar.getInstance().getTime()) + "'");
        
        String condition = "dar='" +darID+ "' AND product='" +productID+ "'";
        
        downloadID = this.getDboperations().update(table, fields, values, condition, "downloadID");
        
        return downloadID;
    }
    
    
    /**
     * UPDATE Download SET (
     *  Download.status='ERROR',
     *  Download.lastActivityTime=<NOW>
     * ) = WHERE downloadID=<downloadID> ;
     * INSERT INTO Error 
     * (errorCode,errorMessage,errorDescription, download) 
     * VALUES (<error.getErrorCode()>, <error.getErrorMessage()>, <error.getErrorDescription()>, <downloadID>);
     * @param downloadID
     * @param error 
     */    
    public String setError(String downloadID, DMMError error) throws SQLException {
        
        this.updateDownload(downloadID, Download.ProductDownloadStatus.ERROR, error.getErrorDescription(), 0);
        return this.errorHandler.addError(false, downloadID, error);
    }

    /**
     * UPDATE DownloadManager SET (
     *  DownloadManager.status='ERROR',
     *  DownloadManager.lastActivityTime=<NOW>
     * ) = WHERE darID=<darID> AND productID=<productID> ;
     * INSERT INTO Error 
     * (errorCode,errorMessage,errorDescription, download) 
     * VALUES (<error.getErrorCode()>, <error.getErrorMessage()>, <error.getErrorDescription()>, <downloadID>);
     * @param darID
     * @param productID
     * @param error 
     */    
    public String setError(String darID, String productID, DMMError error) throws SQLException {
        //This is a trick : when updating the Download table with darID and productID, we return the downloadID (primary key of the Download used in the setting of the error)
        String downloadID = this.updateDownload(darID, productID, Download.ProductDownloadStatus.ERROR, error.getErrorDescription(), 0);
        return this.errorHandler.addError(false, downloadID, error);
    }

    /*
     * Reading from the database
     */
    
    public DataAccessRequest getDAR(String darID) throws SQLException {
        
        DataAccessRequest dar = null;
        
        List<String> fields = new ArrayList<String>();
        
        fields.add("darID");
        fields.add("clientIP");
        fields.add("sensorTaskID");
        fields.add("status");
        
        String table = "DataAccessRequest";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("DataAccessRequest.darID='" + darID + "'");
        
        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            DataAccessRequest.Status status = null;
            status = DataAccessRequest.Status.valueOf(result.get(0).get(3));
            
            dar = new DataAccessRequest(
                    result.get(0).get(0), 
                    result.get(0).get(1), 
                    result.get(0).get(2), 
                    status);
        }
        
        return dar;
    }
    
    public DataAccessRequest getSensorTaskDAR(String sensorTaskID) throws SQLException {
        
        DataAccessRequest dar = null;
        
        List<String> fields = new ArrayList<String>();
        
        fields.add("darID");
        fields.add("clientIP");
        fields.add("sensorTaskID");
        fields.add("status");
        
        String table = "DataAccessRequest";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("DataAccessRequest.sensorTaskID='" + sensorTaskID + "'");
        
        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            DataAccessRequest.Status status = null;
            status = DataAccessRequest.Status.valueOf(result.get(0).get(3));
            
            dar = new DataAccessRequest(
                    result.get(0).get(0), 
                    result.get(0).get(1), 
                    result.get(0).get(2), 
                    status);
        }
        
        return dar;
    }
    
    public DataAccessRequest getSensorTaskDARWithDownloads(String sensorTaskID) throws SQLException, ParseException {
        
        DataAccessRequest dar = null;
        
        List<String> fields = new ArrayList<String>();
        
        fields.add("darID");
        fields.add("clientIP");
        fields.add("sensorTaskID");
        fields.add("status");
        
        String table = "DataAccessRequest";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("DataAccessRequest.darID='" + sensorTaskID + "'");
        
        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            DataAccessRequest.Status status = null;
            status = DataAccessRequest.Status.valueOf(result.get(0).get(3));
            
            dar = new DataAccessRequest(
                    result.get(0).get(0), 
                    result.get(0).get(1), 
                    result.get(0).get(2), 
                    status);
            
            dar.setDownloads(this.getProducts(result.get(0).get(0), null));
        }
        
        return dar;
    }
    
    public DataAccessRequest getSensorTaskDARWithReadyDownloads(String sensorTaskID) throws SQLException, ParseException {
        
        DataAccessRequest dar = null;
        
        List<String> fields = new ArrayList<String>();
        
        fields.add("darID");
        fields.add("clientIP");
        fields.add("sensorTaskID");
        fields.add("status");
        
        String table = "DataAccessRequest";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("DataAccessRequest.darID='" + sensorTaskID + "'");
        
        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            DataAccessRequest.Status status = null;
            status = DataAccessRequest.Status.valueOf(result.get(0).get(3));
            
            dar = new DataAccessRequest(
                    result.get(0).get(0), 
                    result.get(0).get(1), 
                    result.get(0).get(2), 
                    status);
            
            dar.setDownloads(this.getReadyAccessedProducts(result.get(0).get(0), null));
        }
        
        return dar;
    }
    
    public List<Download> getProducts(String darID, Date setTime) throws ParseException, SQLException {

        List<Download> prods = new ArrayList<>();
        
        List<String> fields = new ArrayList<String>();
        
        fields.add("downloadID");
        fields.add("status");
        fields.add("message");
        fields.add("percentCompleted");
        fields.add("lastActivityTime");
        fields.add("startTime");
        fields.add("endTime");
        
        fields.add("productID");
        
        String table = "Download, Product";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("Download.dar='" + darID + "'");
        conditions.add("Download.product=Product.productID");
        
        if (setTime != null) {
            conditions.add("Product.lastUpdateTime>'" + DateHandler.formatDate(setTime) + "'");
        }

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            for (List<String> list : result) {
                
                prods.add(new Download(
                        list.get(0),
                        this.productHandler.getProduct(list.get(7)),           //product
                        Download.ProductDownloadStatus.valueOf(list.get(1)),   //status
                        list.get(2),
                        Integer.valueOf(list.get(3)),  
                        DateHandler.parseBDDDate(list.get(4)), 
                        DateHandler.parseBDDDate(list.get(5)), 
                        DateHandler.parseBDDDate(list.get(6))
                    ));
            }
        }
        
        return prods;
    }

    public List<Download> getReadyProducts(String darID, Date setTime) throws SQLException, ParseException {
        List<Download> prods = new ArrayList<>();
        
        List<String> fields = new ArrayList<String>();
        fields.add("downloadID");
        fields.add("status");
        fields.add("message");
        fields.add("percentCompleted");
        fields.add("lastActivityTime");
        fields.add("startTime");
        fields.add("endTime");
        
        fields.add("productID");
        
        String table = "Download, Product";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("Download.dar='" + darID + "'");
        conditions.add("Download.product=Product.productID");
        conditions.add("Product.availibility='true'");
        conditions.add("Download.status='NOT_STARTED'");

        if (setTime != null) {
            conditions.add("Product.lastUpdateTime>'" + DateHandler.formatDate(setTime) + "'");
        }

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            for (List<String> list : result) {
                
                prods.add(new Download(
                        list.get(0),
                        this.productHandler.getProduct(list.get(7)),           //product
                        Download.ProductDownloadStatus.valueOf(list.get(1)),   //status
                        list.get(2),
                        Integer.valueOf(list.get(3)),  
                        DateHandler.parseBDDDate(list.get(4)), 
                        DateHandler.parseBDDDate(list.get(5)), 
                        DateHandler.parseBDDDate(list.get(6))
                    ));
            }
        }
        
        return prods;
    }

    public List<Download> getReadyAccessedProducts(String darID, Date setTime) throws SQLException, ParseException {
        List<Download> prods = new ArrayList<>();
        
        List<String> fields = new ArrayList<String>();
        fields.add("downloadID");
        fields.add("status");
        fields.add("message");
        fields.add("percentCompleted");
        fields.add("lastActivityTime");
        fields.add("startTime");
        fields.add("endTime");
        
        fields.add("productID");
        
        String table = "Download, Product";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("Download.dar='" + darID + "'");
        conditions.add("Download.product=Product.productID");
        conditions.add("Product.availibility='true'");

        if (setTime != null) {
            conditions.add("Product.lastUpdateTime>'" + DateHandler.formatDate(setTime) + "'");
        }

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            for (List<String> list : result) {
                
                prods.add(new Download(
                        list.get(0),
                        this.productHandler.getProduct(list.get(7)),           //product
                        Download.ProductDownloadStatus.valueOf(list.get(1)),   //status
                        list.get(2),
                        Integer.valueOf(list.get(3)),  
                        DateHandler.parseBDDDate(list.get(4)), 
                        DateHandler.parseBDDDate(list.get(5)), 
                        DateHandler.parseBDDDate(list.get(6))
                    ));
            }
        }
        
        return prods;
    }

    public List<DMMError> getErrors(String downloadID) throws SQLException {
        return this.errorHandler.getErrors(false, downloadID);
    }
    
    
    
}
