/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler.downloadmanager;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import net.eads.astrium.dream.dbhandler.DBOperations;
import net.eads.astrium.dream.dbhandler.DatabaseLoader;
import net.eads.astrium.dream.util.structures.downloadmanager.DMUser;

/**
 *
 * @author re-sulrich
 */
public class DMUserHandler extends DatabaseLoader {

    
    public DMUserHandler() {
        super("DownloadManagerDatabase");
    }

    public DMUserHandler(DBOperations dboperations) {
        super(dboperations);
    }

    public DMUserHandler(String databaseURL, String user, String pass) {
        super(databaseURL, user, pass);
    }
    
    public void addDMUser(
            String dmUserID, String dmUserName, int maxDownloadManagers) throws SQLException {
        
        String table = "DMUser";

        List<String> fields = new ArrayList<String>();

        fields.add("userId");
        fields.add("name");
        fields.add("maxDownloadManagers");

        List<String> depl1 = new ArrayList<String>();
        depl1.add("'" + dmUserID + "'");
        depl1.add("'" + dmUserName + "'");
        depl1.add("'" + maxDownloadManagers + "'");

        List<List<String>> values = new ArrayList<List<String>>();
        values.add(depl1);

        this.getDboperations().insert(
                table,
                fields,
                values);
    }
    
    public DMUser getDMUser(String dmUserID) throws SQLException {
        
        DMUser user = null;
        
        List<String> fields = new ArrayList<String>();
        fields.add("userID");
        fields.add("name");
        fields.add("maxDownloadManagers");

        String table = "DMUser";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("userID='" + dmUserID + "'");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            
            user = new DMUser(result.get(0).get(0), result.get(0).get(1), Integer.valueOf(result.get(0).get(2)));
        }

        return user;
    }

    public List<String> getDownloadManagersIDs(String userID) throws SQLException {
        
        List<String> dms = new ArrayList<>();
        
        List<String> fields = new ArrayList<String>();
        fields.add("downloadManagerID");

        String table = "DownloadManager";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("userID='" + userID + "'");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            
            for (List<String> list : result) {
                dms.add(list.get(0));
            }
        }

        return dms;
    }
    
    /**
     * SELECT COUNT(*) FROM DownloadManager WHERE userID=<userID>
     * @param monitoringServiceID
     * @return 
     */
    public int getNbDownloadManagers(String userID) throws SQLException {
        
        int nbDM = 0;
        
        List<String> f = new ArrayList<String>();
        f.add("*");

        String t = "DownloadManager";

        //Filtering the DB results by app server
        List<String> c = new ArrayList<String>();
        c.add("DownloadManager.userID='"+userID+"'");

        List<List<String>> r = this.getDboperations().select(f, t, c);

        if (r != null && r.size() > 0) {
            nbDM = r.size();
        }
        
        return nbDM;
    }
    /**
     * SELECT maxDownloadManagers FROM DMUser WHERE userID = <userID>
     * @param monitoringServiceID
     * @return 
     */
    public int getMaxDownloadManagers(String userID) throws SQLException {
        
        int maxDM = 0;
        
        List<String> fields = new ArrayList<String>();
        fields.add("maxDownloadManagers");

        String table = "DMUser";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("DMUser.userID='"+userID+"'");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            maxDM = Integer.valueOf(result.get(0).get(0));
        }
        
        return maxDM;
    }
}
