/**
 * --------------------------------------------------------------------------------------------------------
 *   Project                                            :               DREAM
 * --------------------------------------------------------------------------------------------------------
 *   File Name                                          :               MMFASTaskHandler.java
 *   File Type                                          :               Source Code
 *   Description                                        :                *
 * --------------------------------------------------------------------------------------------------------
 *
 * =================================================================
 *             (coffee) COPYRIGHT EADS ASTRIUM LIMITED 2013. All Rights Reserved
 *             This software is supplied by EADS Astrium Limited on the express terms
 *             that it is to be treated as confidential and that it may not be copied,
 *             used or disclosed to others for any purpose except as authorised in
 *             writing by this Company.
 * --------------------------------------------------------------------------------------------------------
 *//*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler.tasking;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.eads.astrium.dream.dbhandler.DBOperations;
import net.eads.astrium.dream.util.DateHandler;
import net.eads.astrium.dream.util.structures.tasking.EarthObservationEquipment;
import net.eads.astrium.dream.util.structures.tasking.OPTTaskingParameters;
import net.eads.astrium.dream.util.structures.tasking.SARTaskingParameters;
import net.eads.astrium.dream.util.structures.tasking.Segment;
import net.eads.astrium.dream.util.structures.tasking.Status;
import net.eads.astrium.dream.util.structures.tasking.enums.RequestType;
import net.eads.astrium.dream.util.structures.tasking.enums.StatusParentType;
import net.eads.astrium.dream.util.structures.tasking.enums.TaskHandlerType;
import net.eads.astrium.dream.util.structures.tasking.enums.TaskType;

/**
 *
 * @author re-sulrich
 */
public class MMFASTaskHandler extends RequestHandler {

    public SensorFeasibilityHandler getSensorFeasibilityHandler() {
        return new SensorFeasibilityHandler(this.getDboperations());
    }
    
    public SensorPlanningHandler getSensorPlanningHandler() {
        return new SensorPlanningHandler(this.getDboperations());
    }
    
    private final String mmfasId;

    public MMFASTaskHandler(String mmfasId) {
        
        super();
        this.mmfasId = mmfasId;
    }

    public MMFASTaskHandler(String mmfasId, DBOperations dboperations) {
        
        super(dboperations);
        this.mmfasId = mmfasId;
    }
    
    public MMFASTaskHandler(String mmfasId, String databaseURL, String user, String pass) {
        super(databaseURL, user, pass);

        System.out.println("URL : " + databaseURL);
        System.out.println("user : " + user);
        System.out.println("pass : " + pass);
        System.out.println("mmfasId : " + mmfasId);
        
        this.mmfasId = mmfasId;
    }

    public Status addNewFeasibilityFinishedStatus(String mmfasTaskId, Date estimatedTimeOfCompletion) throws SQLException {
        
        int percentCompletion = 100;
        String statusIdentifier = "FEASIBILITY COMPLETED";
        String message = "Feasibility study is complete";
        Date now = Calendar.getInstance().getTime();
        Status status = new Status(statusIdentifier, percentCompletion, message, now, estimatedTimeOfCompletion);
        
        String table = "MMFASTask";
        List<String> fields = new ArrayList<>();
        fields.add("status");
        String condition = "taskId='" +mmfasTaskId+ "'";
        
        //SELECT status FROM SensorTask WHERE taskId=<sensorTaskId>
        String oldStatus = this.select(fields, table, Arrays.asList(new String[]{condition})).get(0).get(0);
        //Create new status with the previous of the task
        String statusId = this.statusHandler.createNewStatusWithPrevious(
                statusIdentifier, 
                percentCompletion, 
                message, 
                DateHandler.formatDate(now), 
                DateHandler.formatDate(estimatedTimeOfCompletion), 
                oldStatus);
        //Add new statusId to the values to update in the SensorTask table
        List<String> values = new ArrayList<>();
        values.add(statusId);
        
        this.getDboperations().update(table, fields, values, condition);
        
        return status;
    }
    
    
    public Status addNewPlanningFinishedStatus(String mmfasTaskId, int percentCompletion, Date estimatedTimeOfCompletion) 
            throws SQLException {
        
//        int percentCompletion = 100;
        String statusIdentifier = "PLANNING COMPLETED";
        String message = "Planning is completed. "
                + "Products are now available at the URL given by the DescribeResultAccess "
                + "and in the download managers.";
        Date now = Calendar.getInstance().getTime();
        Status status = new Status(statusIdentifier, percentCompletion, message, now, estimatedTimeOfCompletion);
        
        String table = "MMFASTask";
        List<String> fields = new ArrayList<>();
        fields.add("status");
        String condition = "taskId='" +mmfasTaskId+ "'";
        
        //SELECT status FROM SensorTask WHERE taskId=<sensorTaskId>
        String oldStatus = this.select(fields, table, Arrays.asList(new String[]{condition})).get(0).get(0);
        //Create new status with the previous of the task
        String statusId = this.statusHandler.createNewStatusWithPrevious(
                statusIdentifier, 
                percentCompletion, 
                message, 
                DateHandler.formatDate(now), 
                DateHandler.formatDate(estimatedTimeOfCompletion), 
                oldStatus);
        //Add new statusId to the values to update in the SensorTask table
        List<String> values = new ArrayList<>();
        values.add(statusId);
        
        this.getDboperations().update(table, fields, values, condition);
        
        return status;
    }
    
    public Status addNewPlanningFailedStatus(String mmfasTaskId) 
            throws SQLException {
        
//        int percentCompletion = 100;
        String statusIdentifier = "PLANNING FAILED";
        String message = "Planning has failed. "
                + "No Segments were acquired. Please see segments details for further information.";
        Date now = Calendar.getInstance().getTime();
        Status status = new Status(statusIdentifier, 0, message, now, now);
        
        String table = "MMFASTask";
        List<String> fields = new ArrayList<>();
        fields.add("status");
        String condition = "taskId='" +mmfasTaskId+ "'";
        
        //SELECT status FROM SensorTask WHERE taskId=<sensorTaskId>
        String oldStatus = this.select(fields, table, Arrays.asList(new String[]{condition})).get(0).get(0);
        //Create new status with the previous of the task
        String statusId = this.statusHandler.createNewStatusWithPrevious(
                statusIdentifier, 
                0, 
                message, 
                DateHandler.formatDate(now), 
                DateHandler.formatDate(now), 
                oldStatus);
        //Add new statusId to the values to update in the SensorTask table
        List<String> values = new ArrayList<>();
        values.add(statusId);
        
        this.getDboperations().update(table, fields, values, condition);
        
        return status;
    }
    
    
    public String createPlanningTaskFromFeasibility(
            String feasibilityTaskId) throws SQLException {
        
        String mmfasTaskId = this.createMMFASTask(TaskType.planning, feasibilityTaskId);
        System.out.println("feasi ID : " + feasibilityTaskId + " = " + getRequestId(feasibilityTaskId));
        //To be done : add feasibility/planning mmfasTask in Request
        this.linkMMFASTaskToRequest(mmfasTaskId, getRequestId(feasibilityTaskId));
        
        return mmfasTaskId;
    }
    
    
    
    public String createOPTFeasibilityTask(
            OPTTaskingParameters parameters) throws SQLException {

        String mmfasTaskId = this.createMMFASTask(TaskType.feasibility, null);
        this.saveOPTFeasibilityRequest(mmfasTaskId, parameters);

        return mmfasTaskId;
    }

    public String createSARFeasibilityTask(
            SARTaskingParameters parameters) throws SQLException {

        String mmfasTaskId = this.createMMFASTask(TaskType.feasibility, null);
        this.saveSARFeasibilityRequest(mmfasTaskId, parameters);

        return mmfasTaskId;
    }

    public String createSARPlanningTask(
            SARTaskingParameters parameters) throws SQLException {

        String mmfasTaskId = this.createMMFASTask(TaskType.planning, null);
        this.saveSARSubmitRequest(mmfasTaskId, parameters);

        return mmfasTaskId;
    }

    public String createOPTPlanningTask(
            OPTTaskingParameters parameters) throws SQLException {

        String sensorTaskId = this.createMMFASTask(TaskType.planning, null);
        this.saveOPTSubmitRequest(sensorTaskId, parameters);

        return sensorTaskId;
    }

    public void saveSARFeasibilityRequest(
            String mmfasTaskId,
            SARTaskingParameters parameters) throws SQLException {

        this.saveSARTaskingRequest(TaskHandlerType.mmfas, mmfasTaskId, RequestType.getFeasibility, parameters);
    }

    public void saveOPTFeasibilityRequest(
            String mmfasTaskId,
            OPTTaskingParameters parameters) throws SQLException {

        this.saveOPTTaskingRequest(TaskHandlerType.mmfas, mmfasTaskId, RequestType.getFeasibility, parameters);
    }

    public void saveSARSubmitRequest(
            String mmfasTaskId,
            SARTaskingParameters parameters) throws SQLException {

        this.saveSARTaskingRequest(TaskHandlerType.mmfas, mmfasTaskId, RequestType.submit, parameters);
    }

    public void saveOPTSubmitRequest(
            String mmfasTaskId,
            OPTTaskingParameters parameters) throws SQLException {

        this.saveOPTTaskingRequest(TaskHandlerType.mmfas, mmfasTaskId, RequestType.submit, parameters);
    }

    public void saveCancelRequest(
            String mmfasTaskId) throws SQLException {

        this.createRequest(TaskHandlerType.mmfas, mmfasTaskId, RequestType.cancel);
    }

    public void saveSubmitSegmentByIDRequest(
            String mmfasTaskId) throws SQLException {

        this.createRequest(TaskHandlerType.mmfas, mmfasTaskId, RequestType.submitSegmentByID);
    }

    private String createMMFASTask(TaskType type,String feasibility) throws SQLException {

        String status = statusHandler.createNewStatusPending(StatusParentType.MMFASTASK, type);

        String mmfasTaskId = null;

        String table = "MMFASTask";

        List<String> fields = new ArrayList<String>();

        fields.add("type");

        //Foreign keys
        fields.add("mmfas");
        fields.add("status");
        fields.add("feasibility");

        List<String> depl1 = new ArrayList<String>();
        depl1.add("'" + type + "'");

        //Foreign keys
        depl1.add("'" + mmfasId + "'");
        depl1.add(status);
        depl1.add(feasibility);

        List<List<String>> values = new ArrayList<List<String>>();
        values.add(depl1);

        mmfasTaskId = this.getDboperations().insertReturningId(
                table,
                fields,
                values,
                "taskId");

        return mmfasTaskId;
    }
    
    
    
    
    
    
    
    //----------------------------------------------------------------
    //Getters
    //----------------------------------------------------------------
    
    public Status getStatus(String mmfasTaskId) throws SQLException, ParseException {
        
        return this.statusHandler.getCurrentStatus(StatusParentType.MMFASTASK, mmfasTaskId);
    }
    
    public List<String> getFeasibilityPlanningTasks(String feasibilityTaskId) throws SQLException {
        
        List<String> planningTasks = new ArrayList<>();

        String table = "MMFASTask";
        
        List<String> fields = new ArrayList<String>();
        fields.add("taskId");
        
        List<String> conditions = new ArrayList<String>();
        conditions.add("feasibility='"+feasibilityTaskId+"'");
            
        List<List<String>> result = select(fields, table, conditions);
        
        if (result != null && result.size() > 0){
            for (List<String> list : result) {
                planningTasks.add(list.get(0));
            }
        }
        return planningTasks;
    }
    
    public Map<String, String> getSensorsDARMAHrefs(String mmfasTaskId) throws SQLException {
        
        Map<String, String> sensorsDARMAHrefs = new HashMap<>();
        
        String table = "SensorTask, Sensor, MissionPlanner";
        
        List<String> fields = new ArrayList<>();
        fields.add("Sensor.sensorId");
        fields.add("MissionPlanner.DARMAHref");
        
        List<String> conditions = new ArrayList<>();
        conditions.add("SensorTask.mmfasTask='" + mmfasTaskId + "'");
        conditions.add("Sensor.sensorId=SensorTask.sensor");
        conditions.add("Sensor.platform=MissionPlanner.platform");
        
        List<List<String>> result = select(fields, table, conditions);
        
        if (result != null && result.size() > 0){
            for (List<String> list : result) {
                sensorsDARMAHrefs.put(list.get(0), list.get(1));
            }
        }
        
        return sensorsDARMAHrefs;
    }
    
    public Map<String, String> getSensorTasksInternalMissionPlannersHref(String mmfasTaskId) throws SQLException {
        
        Map<String, String> sensorTasks = new HashMap<>();

        String table = "SensorTask, Sensor, MissionPlanner, ApplicationServer";
        
        List<String> fields = new ArrayList<String>();
        fields.add("SensorTask.taskId");
        fields.add("ApplicationServer.serverBaseAddress");
        fields.add("MissionPlanner.mpId");
        
        List<String> conditions = new ArrayList<String>();
        conditions.add("SensorTask.mmfasTask='"+mmfasTaskId+"'");
        conditions.add("SensorTask.sensor=Sensor.sensorId");
        conditions.add("Sensor.platform=MissionPlanner.platform");
        conditions.add("MissionPlanner.server=ApplicationServer.asId");
            
        System.out.println("" + mmfasTaskId);
        
        List<List<String>> result = select(fields, table, conditions);
        
        for (List<String> list : result) {
            String url = list.get(1) + "/DreamServices/dream/mp/" + list.get(2) + "/eosps";
            
            sensorTasks.put(list.get(0), url);
        }

        return sensorTasks;
    }
    
    public List<String> getSensorTasksIds(String mmfasTaskId, TaskType type) throws SQLException {
        
        List<String> sensorTasks = new ArrayList<>();

        String table = "SensorTask";
        
        List<String> fields = new ArrayList<String>();
        fields.add("taskId");
        
        List<String> conditions = new ArrayList<String>();
        conditions.add("mmfasTask='"+mmfasTaskId+"'");
        if (type != null)
            conditions.add("type='"+type+"'");
            
        List<List<String>> result = select(fields, table, conditions);
        
        if (result != null && result.size() > 0){
            for (List<String> list : result) {
                sensorTasks.add(list.get(0));
            }
        }
        return sensorTasks;
    }
    
    public Map<String, String> getSensorsTasksIds(String mmfasTaskId, TaskType type) throws SQLException {
        
        Map<String,String> sensorTasks = new HashMap<>();

        String table = "SensorTask";
        
        List<String> fields = new ArrayList<String>();
        fields.add("taskId");
        fields.add("sensor");
        
        List<String> conditions = new ArrayList<String>();
        conditions.add("mmfasTask='"+mmfasTaskId+"'");
        if (type != null)
            conditions.add("type='"+type+"'");
            
        List<List<String>> result = select(fields, table, conditions);
        
        if (result != null && result.size() > 0){
            for (List<String> list : result) {
                sensorTasks.put(list.get(1),list.get(0));
            }
        }
        return sensorTasks;
    }
    
    
    public String getRequestId(String mmfasTaskId) throws SQLException {
        
        String requestId = null;
        
        String table = "LNK_MMFASTask_Request";
        
        List<String> fields = new ArrayList<>();
        fields.add("request");
        List<String> conditions = new ArrayList<>();
        conditions.add("mmfasTask='"+mmfasTaskId+"'");
        
        List<List<String>> result = select(fields, table, conditions);
        
        if (result != null && result.size() > 0){
            requestId = result.get(0).get(0);
        }
        
        return requestId;
    }
    
    public EarthObservationEquipment getSegmentEarthObservationEquipment(String segmentID) throws SQLException {
        
        EarthObservationEquipment eoe = null;
        
        String table = "Segment, SensorTask, Sensor, SatellitePlatform, Orbit";
        
        List<String> fields = new ArrayList<>();
        fields.add("SatellitePlatform.satelliteId");
        fields.add("SatellitePlatform.noradName");
        fields.add("SatellitePlatform.description");
        fields.add("Orbit.orbitType");
        fields.add("Sensor.sensorId");
        fields.add("Sensor.type");
        
        List<String> conditions = new ArrayList<>();
        
        conditions.add("Segment.segmentId='"+segmentID+"'");
        conditions.add("(SensorTask.taskId=Segment.feasibility OR SensorTask.taskId=Segment.planning)");
        conditions.add("SensorTask.sensor=Sensor.sensorId");
        conditions.add("Sensor.platform=SatellitePlatform.satelliteId");
        conditions.add("SatellitePlatform.satelliteId=Orbit.satellite");
        
        List<List<String>> result = select(fields, table, conditions);
        
        if (result != null && result.size() > 0){
            List<String> list = result.get(0);
            
            eoe = new EarthObservationEquipment(
                    list.get(0), 
                    list.get(1), 
                    list.get(2), 
                    list.get(3), 
                    list.get(4), 
                    list.get(5)
                );
        }
        
        return eoe;
    }
    
}
