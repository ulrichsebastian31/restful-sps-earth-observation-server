/**
 * --------------------------------------------------------------------------------------------------------
 *   Project                                            :               DREAM
 * --------------------------------------------------------------------------------------------------------
 *   File Name                                          :               FASApplicationLoader.java
 *   File Type                                          :               Source Code
 *   Description                                        :                *
 * --------------------------------------------------------------------------------------------------------
 *
 * =================================================================
 *             (coffee) COPYRIGHT EADS ASTRIUM LIMITED 2013. All Rights Reserved
 *             This software is supplied by EADS Astrium Limited on the express terms
 *             that it is to be treated as confidential and that it may not be copied,
 *             used or disclosed to others for any purpose except as authorised in
 *             writing by this Company.
 * --------------------------------------------------------------------------------------------------------
 *//*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import net.eads.astrium.dream.util.DateHandler;
import net.eads.astrium.dream.util.structures.GroundStation;
import net.eads.astrium.dream.util.structures.Orbit;
import net.eads.astrium.dream.util.structures.SatellitePlatform;
import net.eads.astrium.dream.util.structures.tasking.geometries.Point;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author re-sulrich
 */
public class FASApplicationLoader extends ApplicationServerLoader {

    public FASApplicationLoader(String applicationServerId) {
        super(applicationServerId);
    }

    public FASApplicationLoader(String applicationServerId, DBOperations dboperations) {
        
        super(applicationServerId, dboperations);
    }
    
    public FASApplicationLoader(String applicationServerId, String databaseURL, String user, String pass) {
        super(applicationServerId, databaseURL, user, pass);
    }
    
    
    public List<String> getFASIds() throws SQLException {

        List<String> fasIds = new ArrayList<String>();

        List<String> fields = new ArrayList<String>();
        fields.add("fasId");

        String table = "FAS";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("server='" + getApplicationServerId() + "'");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        for (List<String> entry : result) {

            fasIds.add(entry.get(0));
        }

        return fasIds;
    }

    public List<String> getFASSatellitesIds() throws SQLException {

        List<String> satellitesIds = new ArrayList<String>();

        List<String> fields = new ArrayList<String>();
        fields.add("platform");

        String table = "FAS";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("server='" + getApplicationServerId() + "'");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        for (List<String> entry : result) {

            satellitesIds.add(entry.get(0));
        }

        return satellitesIds;
    }

    public void deleteDirectory(File dir) {
        
        File[] files = dir.listFiles();
        for (int i = 0; i < files.length; i++) {
            File file = files[i];
            if (file.isDirectory()) {
                deleteDirectory(file);
            }
            else {
                file.delete();
            }
        }
        dir.delete();
    }
    
    public void createFASConfigurationFileFolder() throws SQLException, IOException {

        String confFolderBasePath = ApplicationServerLoader.DREAM_WS_CONF_FOLDER + "fas" + File.separator;
        
        //Delete previous FAS folder if existing
        
        File file = new File(confFolderBasePath);
        if(file.exists() && file.isDirectory()) {
            deleteDirectory(file);
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
                Logger.getLogger(FASApplicationLoader.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println("Deleted");
        Files.createDirectories(Paths.get(confFolderBasePath));
        List<String> satellites = getFASSatellitesIds();

        //LNK_Satellite_GroundStation

        for (String satellite : satellites) {

            String satelliteConfFolder = confFolderBasePath + satellite + File.separator;
            String satelliteConfFileFolderEmptyWhileBugFixedOnEOCFI = satelliteConfFolder + "satellite" + File.separator;
            String satelliteConfFileFolder = satelliteConfFolder + "satellite_tmp" + File.separator;
            String antennaConfFolder = satelliteConfFolder + "antenna" + File.separator;
            String stationConfFolder = satelliteConfFolder + "Ground Station" + File.separator;

            Files.createDirectory(Paths.get(satelliteConfFolder));
            Files.createDirectory(Paths.get(stationConfFolder));
            Files.createDirectory(Paths.get(satelliteConfFileFolderEmptyWhileBugFixedOnEOCFI));
            Files.createDirectory(Paths.get(satelliteConfFileFolder));
            Files.createDirectory(Paths.get(antennaConfFolder));
            
            getSatelliteConfigurationFile(satelliteConfFileFolder, satellite);
            getAntennaSDF(antennaConfFolder, satellite);

//            System.out.println("");
//            System.out.println("Antenna done");
//            System.out.println("");
            
            getGroundStationFiles(stationConfFolder, satellite);

//            System.out.println("");
//            System.out.println("Ground Station done");
//            System.out.println("");
            
            String osfConfFolder = satelliteConfFolder + "OSF" + File.separator;
            Files.createDirectory(Paths.get(osfConfFolder));
            getOSFFiles(osfConfFolder, satellite);

//            System.out.println("");
//            System.out.println("OSF done");
//            System.out.println("");
            
            String sensorsConfFolder = satelliteConfFolder + "sensors" + File.separator;
            Files.createDirectories(Paths.get(sensorsConfFolder));

            List<String> sensors = getSensorsIds(satellite);

//            System.out.println("Sensors : " + sensors.size());
            
            for (String sensor : sensors) {

                String sensorConfFolder = sensorsConfFolder + sensor + File.separator + "SDF" + File.separator;
                Files.createDirectories(Paths.get(sensorConfFolder));

                this.getSDFFiles(sensorConfFolder, sensor);
            }
        }
    }

    void getSatelliteConfigurationFile(String satelliteConfFolderPath, String satelliteId) {


        String scfFileName = "SCF_"
                + satelliteId + "_"
                + "00000000T000000_"
                + "99999999T999999_"
                + "0001.xml";

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

        try {
            SatellitePlatform satellite = getSatellite(satelliteId);

            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document document = dBuilder.newDocument();
            document.setXmlVersion("1.0");

            Element eef = document.createElement("Earth_Explorer_File");
            document.appendChild(eef);
            eef.setAttribute("schemaVersion", "2.1");
            eef.setAttribute("xmlns", "http://eop-cfi.esa.int/CFI");
            eef.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
            eef.setAttribute("xsi:schemaLocation", "http://eop-cfi.esa.int/CFI http://eop-cfi.esa.int/CFI/EE_CFI_SCHEMAS/EO_OPER_INT_SATCFG_0201.XSD");

            Element eeh = document.createElement("Earth_Explorer_Header");
            eef.appendChild(eeh);
            Element fh = document.createElement("Fixed_Header");
            eeh.appendChild(fh);

            Element fn = document.createElement("File_Name");
            fn.setTextContent(scfFileName);
            eeh.appendChild(fn);
            Element fd = document.createElement("File_Description");
            fd.setTextContent("Satellite Configuration");
            eeh.appendChild(fd);
            Element n = document.createElement("Notes");
            fd.setTextContent("Satellite Configuration");
            eeh.appendChild(n);
            Element m = document.createElement("Mission");
            fd.setTextContent("" + satelliteId);
            eeh.appendChild(m);
            Element fc = document.createElement("File_Class");
            fd.setTextContent("");
            eeh.appendChild(fc);
            Element ft = document.createElement("File_Type");
            fd.setTextContent("INT_SATCFG");
            eeh.appendChild(ft);
            Element fv = document.createElement("File_Version");
            fd.setTextContent("0001");
            eeh.appendChild(fv);
            Element vp = document.createElement("Validity_Period");
            Element vps = document.createElement("Validity_Start");
            vps.setTextContent("00000000T000000");
            vp.appendChild(vps);
            Element vpe = document.createElement("Validity_Stop");
            vpe.setTextContent("99999999T999999");
            vp.appendChild(vpe);
            eeh.appendChild(vp);
            Element s = document.createElement("Source");
            Element ss = document.createElement("System");
            vpe.setTextContent("FAS");
            s.appendChild(ss);
            Element sc = document.createElement("Creator");
            vpe.setTextContent("");
            s.appendChild(sc);
            Element scv = document.createElement("Creator_Version");
            vpe.setTextContent("");
            s.appendChild(scv);
            Element scd = document.createElement("Creation_Date");
            vpe.setTextContent(DateHandler.formatDateToEocfi(new Date()));
            s.appendChild(scd);
            eeh.appendChild(s);

            Element vh = document.createElement("Variable_Header");
            eeh.appendChild(vh);





            Element db = document.createElement("Data_Block");
            db.setAttribute("type", "xml");
            eef.appendChild(db);

            Element sn = document.createElement("Satellite_Name");
            sn.setTextContent(satellite.getName());
            db.appendChild(sn);

            Element nd = document.createElement("NORAD_Data");
            db.appendChild(nd);
            Element satNum = document.createElement("Satellite_Number");
            satNum.setTextContent("1");
            nd.appendChild(satNum);
            Element nsm = document.createElement("NORAD_Sat_Name");
            nsm.setTextContent(satellite.getNoradName());
            nd.appendChild(nsm);
            Element id = document.createElement("Int_Designator");
            id.setTextContent(satellite.getId());
            nd.appendChild(id);
            
            //Orbit information
            Orbit orb = satellite.getOrbit();
            
            
            Element li = document.createElement("Lib_Init");
            db.appendChild(li);

            
            
            Element lt = document.createElement("Low_Tolerances");
            li.appendChild(lt);
            Element minsma = document.createElement("Min_Semi_Major_Axis");
            minsma.setTextContent(orb.getLow_Min_Semi_Major_Axis());
            lt.appendChild(minsma);
            Element maxsma = document.createElement("Max_Semi_Major_Axis");
            maxsma.setTextContent(orb.getLow_Max_Semi_Major_Axis());
            lt.appendChild(maxsma);
            Element minI = document.createElement("Min_Inclination");
            minI.setTextContent(orb.getLow_Min_Inclination());
            lt.appendChild(minI);
            Element maxI = document.createElement("Max_Inclination");
            maxI.setTextContent(orb.getLow_Max_Inclination());
            lt.appendChild(maxI);
            Element minE = document.createElement("Min_Eccentricity");
            minE.setTextContent(orb.getLow_Min_Eccentricity());
            lt.appendChild(minE);
            Element maxE = document.createElement("Max_Eccentricity");
            maxE.setTextContent(orb.getLow_Max_Eccentricity());
            lt.appendChild(maxE);

            Element tt = document.createElement("Tight_Tolerances");
            li.appendChild(tt);
            Element tminsma = document.createElement("Min_Semi_Major_Axis");
            tminsma.setTextContent(orb.getTight_Min_Semi_Major_Axis());
            tt.appendChild(tminsma);
            Element tmaxsma = document.createElement("Max_Semi_Major_Axis");
            tmaxsma.setTextContent(orb.getTight_Max_Semi_Major_Axis());
            tt.appendChild(tmaxsma);
            Element tminI = document.createElement("Min_Inclination");
            tminI.setTextContent(orb.getTight_Min_Inclination());
            tt.appendChild(tminI);
            Element tmaxI = document.createElement("Max_Inclination");
            tmaxI.setTextContent(orb.getTight_Max_Inclination());
            tt.appendChild(tmaxI);
            Element tminE = document.createElement("Min_Eccentricity");
            tminE.setTextContent(orb.getTight_Min_Eccentricity());
            tt.appendChild(tminE);
            Element tmaxE = document.createElement("Max_Eccentricity");
            tmaxE.setTextContent(orb.getTight_Max_Eccentricity());
            tt.appendChild(tmaxE);


            Element oi = document.createElement("Orbit_Init");
            db.appendChild(oi);

            Element ominsma = document.createElement("Min_Semi_Major_Axis");
            ominsma.setTextContent(orb.getOrbit_Min_Semi_Major_Axis());
            oi.appendChild(ominsma);
            Element onomsma = document.createElement("Nom_Semi_Major_Axis");
            onomsma.setTextContent(orb.getOrbit_Nom_Semi_Major_Axis());
            oi.appendChild(onomsma);
            Element omaxsma = document.createElement("Max_Semi_Major_Axis");
            omaxsma.setTextContent(orb.getOrbit_Max_Semi_Major_Axis());
            oi.appendChild(omaxsma);
            Element ominI = document.createElement("Min_Inclination");
            ominI.setTextContent(orb.getOrbit_Min_Inclination());
            oi.appendChild(ominI);
            Element oNomI = document.createElement("Nom_Inclination");
            oNomI.setTextContent(orb.getOrbit_Nom_Inclination());
            oi.appendChild(oNomI);
            Element omaxI = document.createElement("Max_Inclination");
            omaxI.setTextContent(orb.getOrbit_Max_Inclination());
            oi.appendChild(omaxI);
            Element oNomE = document.createElement("Nom_Eccentricity");
            oNomE.setTextContent(orb.getOrbit_Nom_Eccentricity());
            oi.appendChild(oNomE);
            Element oNomAP = document.createElement("Nom_Arg_Perigee");
            oNomAP.setTextContent(orb.getOrbit_Nom_Arg_Perigee());
            oi.appendChild(oNomAP);

//            System.out.println(satelliteConfFolderPath + scfFileName);
            
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(document);
            
            StreamResult result = new StreamResult(new StringWriter());
            
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            transformer.transform(source, result);
            
            //writing to file
            FileOutputStream fop = null;
            try {
                
                File file = new File(satelliteConfFolderPath + scfFileName);
                if (!file.exists())
                    file.createNewFile();
                
                fop = new FileOutputStream(file);

                // get the content in bytes
                String xmlString = result.getWriter().toString();
//                System.out.println(xmlString);
                byte[] contentInBytes = xmlString.getBytes();

                fop.write(contentInBytes);
                fop.flush();
                fop.close();

//                System.out.println("Done");

            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (fop != null) {
                        fop.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        } catch (ParserConfigurationException ex) {
            Logger.getLogger(ApplicationServerLoader.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerConfigurationException ex) {
            Logger.getLogger(ApplicationServerLoader.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(ApplicationServerLoader.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
//            Logger.getLogger(ApplicationServerLoader.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void getAntennaSDF(String satelliteConfFolderPath, String satelliteId) throws SQLException, IOException {
        
        String antSDFFileName = "ADF_"
                + satelliteId + "_"
                + "00000000T000000_"
                + "99999999T999999_"
                + "0001.xml";
//        System.out.println("" + satelliteId);
        Path path = this.getDboperations().loadFileOnDisk(
                "antennaSdfFileContent", 
                "SatellitePlatform", 
                "satelliteId='" + satelliteId+ "'", 
//                null,
                satelliteConfFolderPath + antSDFFileName);

//        System.out.println("" + path);
    }
    
    void getGroundStationFiles(String gsFolderPath, String satelliteId) throws SQLException, IOException {

        String gsFileName = "STN_"
                + satelliteId + "_"
                + "00000000T000000_"
                + "99999999T999999_"
                + "0001.xml";

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

        try {
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document document = dBuilder.newDocument();
            document.setXmlVersion("1.0");

            Element eef = document.createElement("Earth_Explorer_File");
            document.appendChild(eef);
            eef.setAttribute("schemaVersion", "2.1");
            eef.setAttribute("xmlns", "http://eop-cfi.esa.int/CFI");
            eef.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
            eef.setAttribute("xsi:schemaLocation", "http://eop-cfi.esa.int/CFI http://eop-cfi.esa.int/CFI/EE_CFI_SCHEMAS/EO_OPER_INT_SATCFG_0201.XSD");

            Element eeh = document.createElement("Earth_Explorer_Header");
            eef.appendChild(eeh);
            Element fh = document.createElement("Fixed_Header");
            eeh.appendChild(fh);

            Element fn = document.createElement("File_Name");
            fn.setTextContent(gsFileName);
            eeh.appendChild(fn);
            Element fd = document.createElement("File_Description");
            fd.setTextContent("Satellite Configuration");
            eeh.appendChild(fd);
            Element n = document.createElement("Notes");
            n.setTextContent("Satellite Configuration");
            eeh.appendChild(n);
            Element m = document.createElement("Mission");
            m.setTextContent("" + satelliteId);
            eeh.appendChild(m);
            Element fc = document.createElement("File_Class");
            fc.setTextContent("");
            eeh.appendChild(fc);
            Element ft = document.createElement("File_Type");
            ft.setTextContent("INT_SATCFG");
            eeh.appendChild(ft);
            Element fv = document.createElement("File_Version");
            fv.setTextContent("0001");
            eeh.appendChild(fv);
            Element vp = document.createElement("Validity_Period");
            Element vps = document.createElement("Validity_Start");
            vps.setTextContent("00000000T000000");
            vp.appendChild(vps);
            Element vpe = document.createElement("Validity_Stop");
            vpe.setTextContent("99999999T999999");
            vp.appendChild(vpe);
            eeh.appendChild(vp);
            Element s = document.createElement("Source");
            Element ss = document.createElement("System");
            ss.setTextContent("FAS");
            s.appendChild(ss);
            Element sc = document.createElement("Creator");
            sc.setTextContent("");
            s.appendChild(sc);
            Element scv = document.createElement("Creator_Version");
            scv.setTextContent("");
            s.appendChild(scv);
            Element scd = document.createElement("Creation_Date");
            scd.setTextContent(DateHandler.formatDateToEocfi(new Date()));
            s.appendChild(scd);
            eeh.appendChild(s);

            Element vh = document.createElement("Variable_Header");
            eeh.appendChild(vh);

            
            Element db = document.createElement("Data_Block");
            db.setAttribute("type", "xml");
            eef.appendChild(db);
            
            List<GroundStation> stations = getGroundStations(satelliteId);
            
            Element groundStations = document.createElement("List_of_Ground_Stations");
                groundStations.setAttribute("count", "" + stations.size());
            db.appendChild(groundStations);
            
            for (GroundStation station : stations) {
                
                Element groundStation = document.createElement("Ground_Station");
                groundStations.appendChild(groundStation);
            
                Element id = document.createElement("Station_id");
                id.setTextContent(station.getId());
                groundStation.appendChild(id);
                Element name = document.createElement("Descriptor");
                name.setTextContent(station.getName());
                groundStation.appendChild(name);
                Element ant = document.createElement("Antenna");
                ant.setTextContent(station.getAntennaType());
                groundStation.appendChild(ant);
                Element pur = document.createElement("Purpose");
                pur.setTextContent(station.getPurpose());
                groundStation.appendChild(pur);
                Element type = document.createElement("Type");
                type.setTextContent(station.getType());
                groundStation.appendChild(type);
                
                Element loc = document.createElement("Location");
                groundStation.appendChild(loc);
                Element lon = document.createElement("Long");
                    lon.setAttribute("unit", "deg");
                lon.setTextContent(getFormattedDouble(station.getLon()));
                loc.appendChild(lon);
                Element lat = document.createElement("Lat");
                    lat.setAttribute("unit", "deg");
                lat.setTextContent(getFormattedDouble(station.getLat()));
                loc.appendChild(lat);
                Element alt = document.createElement("Alt");
                    alt.setAttribute("unit", "m");
                alt.setTextContent(getFormattedDouble(station.getAlt()));
                loc.appendChild(alt);
                
                Element defaultel = document.createElement("Default_El");
                defaultel.setAttribute("unit", "deg");
                defaultel.setTextContent(getFormattedDouble(station.getDefaultElevation()));
                groundStation.appendChild(defaultel);
                
                Element lomp = document.createElement("List_of_Mask_Points");
                lomp.setAttribute("count", "" + station.getMaskPoints().size());
                groundStation.appendChild(lomp);
                for (Point point : station.getMaskPoints()) {
                    
                    Element mp = document.createElement("Mask_Point");
                    lomp.appendChild(mp);
                    
                    Element az = document.createElement("Az");
                    az.setAttribute("unit", "deg");
                    az.setTextContent(getFormattedDouble(point.getLongitude()));
                    mp.appendChild(az);
                    Element el = document.createElement("El");
                    el.setAttribute("unit", "deg");
                    el.setTextContent(getFormattedDouble(point.getLatitude()));
                    mp.appendChild(el);
                }
            }
            
//            System.out.println(gsFolderPath + gsFileName);
            
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(document);
            
            StreamResult result = new StreamResult(new StringWriter());
            
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "5");
            transformer.transform(source, result);
            
            //writing to file
            FileOutputStream fop = null;
            try {
                
                File file = new File(gsFolderPath + gsFileName);
                if (!file.exists())
                    file.createNewFile();
                
                fop = new FileOutputStream(file);

                // get the content in bytes
                String xmlString = result.getWriter().toString();
//                System.out.println(xmlString);
                byte[] contentInBytes = xmlString.getBytes();

                fop.write(contentInBytes);
                fop.flush();
                fop.close();

//                System.out.println("Done");

            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (fop != null) {
                        fop.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            

        } catch (ParserConfigurationException ex) {
            Logger.getLogger(ApplicationServerLoader.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerConfigurationException ex) {
            Logger.getLogger(ApplicationServerLoader.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(ApplicationServerLoader.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ApplicationServerLoader.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(ApplicationServerLoader.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void getOSFFiles(String osfFolderPath, String satelliteId) throws SQLException, IOException {

        List<String> fields = new ArrayList<String>();
        fields.add("OSF.osfId");
        fields.add("validityStart");
        fields.add("validityStop");

        String table = "OSF,LNK_Satellite_OSF,SatellitePlatform";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("SatellitePlatform.satelliteId='" + satelliteId + "'");
        conditions.add("SatellitePlatform.satelliteId=LNK_Satellite_OSF.satellite");
        conditions.add("OSF.osfId=LNK_Satellite_OSF.osfId");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        for (List<String> entry : result) {

            if (entry.size() > 2) {

                String osfId = entry.get(0);
                Calendar validityStart = Calendar.getInstance();
                Calendar validityStop = Calendar.getInstance();
                try {
                    validityStart.setTime(DateHandler.parseBDDDate(entry.get(1)));
                    validityStop.setTime(DateHandler.parseBDDDate(entry.get(2)));
                } catch (ParseException ex) {
                    Logger.getLogger(ApplicationServerLoader.class.getName()).log(Level.SEVERE, null, ex);
                }

                String osfFileName =
                        "OSF_"
                        + satelliteId + "_"
                        + DateHandler.formatDateToEocfi(validityStart.getTime()) + "_"
                        + DateHandler.formatDateToEocfi(validityStop.getTime()) + "_"
                        + osfId + ".xml";

                Path path = this.getDboperations().loadFileOnDisk("content", "OSF", "OSF.osfId="+osfId, osfFolderPath + osfFileName);
                
//                System.out.println("Loaded : " + path);
            }
        }
    }

    void getSDFFiles(String sdfFolderPath, String sensorId) throws SQLException, IOException {

        String sensorType = getSensorType(sensorId);

        List<String> fields = new ArrayList<String>();
        fields.add("SDF.sdfId");
        fields.add("InstrumentMode.imId");

        String table = "SDF, Sensor, InstrumentMode";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("Sensor.sensorId='" + sensorId + "'");

        if (sensorType.equalsIgnoreCase("OPT")) {

            table += ", OPTIMCharacteristics";
            
            conditions.add("Sensor.sensorId=OPTIMCharacteristics.sensor");
            conditions.add("OPTIMCharacteristics.sdfFile=SDF.sdfId");
            conditions.add("OPTIMCharacteristics.instMode=InstrumentMode.imId");
        }
        if (sensorType.equalsIgnoreCase("SAR")) {

            table += ", SARIMCharacteristics";
            
            conditions.add("Sensor.sensorId=SARIMCharacteristics.sensor");
            conditions.add("SARIMCharacteristics.sdfFile=SDF.sdfId");
            conditions.add("SARIMCharacteristics.instMode=InstrumentMode.imId");
        }

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        for (List<String> entry : result) {

            if (entry.size() > 0) {

                String sdfId = entry.get(0);
                String instrumentMode = entry.get(1);

                String sdfFileName =
                        "SDF_"
                        + sensorId + "_"
                        + instrumentMode + "_"
        
                        + "00000000T000000" + "_"
                        + "99999999T999999" + "_"
                        + "0001" + ".xml";
//                      + sdfId;

                Path path = this.getDboperations().loadFileOnDisk("content", "SDF", "sdfId=" + sdfId, sdfFolderPath + sdfFileName);
            }
        }
    }

    static String getFormattedDouble(double number) throws ParseException {
        
        double d = number;
        String form = "";
        
        if (d < 0.0) {
            form += "-";
            d = -d;
        } else
            form += "+";
            
        if (d < 100)
            form += "0";
        if (d < 10)
            form += "0";
        
        int intd = (int)d;
        form += "" + intd + ".";
        
        String nb = "" + (d - intd);
        nb = nb.substring(2);
        int nbDecimal = nb.length();
        
        if (nbDecimal > 5) {
            form += nb.substring(0, 5);
        }
        else {
            form += nb;
            for (int i = 0; i < 5 - nbDecimal; i++) {
                form += "0";
            }
        }
        
        return form;
    }
    
    private List<GroundStation> getGroundStations(String platform) throws SQLException {

        List<GroundStation> stations = new ArrayList<GroundStation>();

        List<String> fields = new ArrayList<String>();
        fields.add("groundStationId");
        fields.add("name");
        fields.add("type");
        fields.add("antennaType");
        fields.add("purpose");
        fields.add("longitude");
        fields.add("latitude");
        fields.add("altitude");
        fields.add("defaultElevation");
        
        fields.add("maskPointsList");

        String table = "GroundStation, LNK_Satellite_GroundStation";

        //Filtering the DB results by sensor type
        List<String> conditions = new ArrayList<String>();
        conditions.add("LNK_Satellite_GroundStation.platform='" + platform + "'");
        conditions.add("GroundStation.groundStationId= LNK_Satellite_GroundStation.station");

        List<List<String>> result = getDboperations().select(fields, table, conditions);

        
        for (List<String> entry : result) {

            List<String> list = entry;
            
            String id = list.get(0);
            String name = list.get(1);
            String type = list.get(2);
            String antennaType = list.get(3);
            String purpose = list.get(4);
            double lon = Double.valueOf(list.get(5));
            double lat = Double.valueOf(list.get(6));
            double alt = Double.valueOf(list.get(7));
            double defaultEl = Double.valueOf(list.get(8));
            
            String[] mps = list.get(9).split(" ");
            List<Point> maskPoints = new ArrayList<Point>();
            
            for (int i = 0; i < mps.length; i++) {
                String mp = mps[i];
                String[] coords = mp.split(",");
                if (coords.length > 1) {
                    maskPoints.add(new Point(Double.valueOf(coords[0]), Double.valueOf(coords[1]), 0.0));
                }
            }
            GroundStation station = new GroundStation(id, name, type, antennaType, purpose, defaultEl, lon, lat, alt, maskPoints);
            stations.add(station);
        }
        return stations;
    }

    private SatellitePlatform getSatellite(String platform) throws SQLException {

        SatellitePlatform satellite = null;

        List<String> fields = new ArrayList<String>();
        fields.add("noradName");
        fields.add("name");
        fields.add("description");
        fields.add("href");

        fields.add("orbitType");
        fields.add("low_Min_Semi_Major_Axis");
        fields.add("low_Max_Semi_Major_Axis");
        fields.add("low_Min_Inclination");
        fields.add("low_Max_Inclination");
        fields.add("low_Min_Eccentricity");
        fields.add("low_Max_Eccentricity");
        fields.add("tight_Min_Semi_Major_Axis");
        fields.add("tight_Max_Semi_Major_Axis");
        fields.add("tight_Min_Inclination");
        fields.add("tight_Max_Inclination");
        fields.add("tight_Min_Eccentricity");
        fields.add("tight_Max_Eccentricity");
        fields.add("orbit_Min_Semi_Major_Axis");
        fields.add("orbit_Nom_Semi_Major_Axis");
        fields.add("orbit_Max_Semi_Major_Axis");
        fields.add("orbit_Min_Inclination");
        fields.add("orbit_Nom_Inclination");
        fields.add("orbit_Max_Inclination");
        fields.add("orbit_Nom_Eccentricity");
        fields.add("orbit_Nom_Arg_Perigee");

        String table = "SatellitePlatform, Orbit";

        //Filtering the DB results by sensor type
        List<String> conditions = new ArrayList<String>();
        conditions.add("SatellitePlatform.satelliteId='" + platform + "'");
        conditions.add("SatellitePlatform.satelliteId= Orbit.satellite");

        List<List<String>> result = getDboperations().select(fields, table, conditions);

        for (List<String> entry : result) {

            List<String> list = entry;

            satellite = new SatellitePlatform(
                    platform,
                    list.get(0),
                    list.get(1),
                    list.get(2),
                    list.get(3),
                    new Orbit(list.get(4),
                    list.get(5),
                    list.get(6),
                    list.get(7),
                    list.get(8),
                    list.get(9),
                    list.get(10),
                    list.get(11),
                    list.get(12),
                    list.get(13),
                    list.get(14),
                    list.get(15),
                    list.get(16),
                    list.get(17),
                    list.get(18),
                    list.get(19),
                    list.get(20),
                    list.get(21),
                    list.get(22),
                    list.get(23),
                    list.get(24)));
        }
        return satellite;
    }

    private List<String> getSensorsIds(String satelliteId) throws SQLException {

        List<String> sensors = new ArrayList<String>();

        String table = "Sensor";

        List<String> fields = new ArrayList<String>();
        fields.add("sensorId");

        //Filtering the DB results by platform
        List<String> conditions = new ArrayList<String>();
        conditions.add("platform='" + satelliteId + "'");

        List<List<String>> result = getDboperations().select(fields, table, conditions);

        for (List<String> list : result) {
            for (String string : list) {

                sensors.add(string);
            }
        }

        return sensors;
    }

    private String getSensorType(String sensorId) throws SQLException {

        String sensorType = "";

        List<String> fields = new ArrayList<String>();
        fields.add("type");

        String table = "Sensor";
        List<String> conditions = new ArrayList<String>();
        conditions.add("sensorId='" + sensorId + "'");

        List<List<String>> sensors = getDboperations().select(fields, table, conditions);

        List<String> list = sensors.get(0);
        sensorType = list.get(0);

        return sensorType;
    }

}
