/**
 * --------------------------------------------------------------------------------------------------------
 *   Project                                            :               DREAM
 * --------------------------------------------------------------------------------------------------------
 *   File Name                                          :               SensorAdminHandler.java
 *   File Type                                          :               Source Code
 *   Description                                        :                *
 * --------------------------------------------------------------------------------------------------------
 *
 * =================================================================
 *             (coffee) COPYRIGHT EADS ASTRIUM LIMITED 2013. All Rights Reserved
 *             This software is supplied by EADS Astrium Limited on the express terms
 *             that it is to be treated as confidential and that it may not be copied,
 *             used or disclosed to others for any purpose except as authorised in
 *             writing by this Company.
 * --------------------------------------------------------------------------------------------------------
 *//*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler.admin;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import net.eads.astrium.dream.dbhandler.DatabaseLoader;
import net.eads.astrium.dream.util.structures.OPTSensor;
import net.eads.astrium.dream.util.structures.SARSensor;

/**
 *
 * @author re-sulrich
 */
public class SensorAdminHandler extends DatabaseLoader {
    
    public SensorAdminHandler() {
        super("MMFASDatabase");
    }
    
    /**
     * 
     * @param satelliteId
     * @param sensor
     * @throws SQLException 
     */
    public void addOPTSensor(String satelliteId, OPTSensor sensor) throws SQLException {
        
        String table = "Sensor";
        
        List<String> fields = new ArrayList<String>();
        fields.add("sensorId");
        fields.add("sensorName");
        fields.add("sensorDescription");
        fields.add("type");
        fields.add("bandType");
        fields.add("minLatitude");
        fields.add("maxLatitude");
        fields.add("minLongitude");
        fields.add("maxLongitude");
        
        fields.add("mass");
        fields.add("maxPowerConsumption");
        fields.add("acqMethod");
        fields.add("applications");
        
        fields.add("platform");

        List<String> s = new ArrayList<String>();
        s.add(sensor.getSensorId());
        s.add(sensor.getSensorName());
        s.add(sensor.getSensorDescription());
        s.add(sensor.getSensorType());
        s.add(sensor.getBandType());
        s.add(sensor.getMinLatitude());
        s.add(sensor.getMaxLatitude());
        s.add(sensor.getMinLongitude());
        s.add(sensor.getMaxLongitude());
        s.add(sensor.getInstrumentMass());
        s.add(sensor.getMaxPowerConsumption());
        s.add(sensor.getAcquisitionMethod());
        String apps = "";
        for (String string : sensor.getApplications()) {
            apps += "" + string + ",";
        }
        if (apps != null && apps.contains(",")) {
            apps = apps.substring(0, apps.lastIndexOf(","));
        }
        
        s.add(apps);
        
        s.add(satelliteId);
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(s);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
        
        this.addOPTSensorChar(sensor);
    }
    
    /**
     * 
     * @param satelliteId
     * @param sensor
     * @throws SQLException 
     */
    public void addSARSensor(String satelliteId, SARSensor sensor) throws SQLException {
        
        String table = "Sensor";
        
        List<String> fields = new ArrayList<String>();
        fields.add("sensorId");
        fields.add("sensorName");
        fields.add("sensorDescription");
        fields.add("type");
        fields.add("bandType");
        fields.add("minLatitude");
        fields.add("maxLatitude");
        fields.add("minLongitude");
        fields.add("maxLongitude");
        
        fields.add("mass");
        fields.add("maxPowerConsumption");
        fields.add("acqMethod");
        fields.add("applications");
        
        fields.add("platform");

        List<String> s = new ArrayList<String>();
        s.add(sensor.getSensorId());
        s.add(sensor.getSensorName());
        s.add(sensor.getSensorDescription());
        s.add(sensor.getSensorType());
        s.add(sensor.getBandType());
        s.add(sensor.getMinLatitude());
        s.add(sensor.getMaxLatitude());
        s.add(sensor.getMinLongitude());
        s.add(sensor.getMaxLongitude());
        s.add(sensor.getInstrumentMass());
        s.add(sensor.getMaxPowerConsumption());
        s.add(sensor.getAcquisitionMethod());
        String apps = "";
        for (String string : sensor.getApplications()) {
            apps += "" + string + ",";
        }
        if (apps != null && apps.contains(",")) {
            apps = apps.substring(0, apps.lastIndexOf(","));
        }
        
        s.add(apps);
        
        s.add(satelliteId);
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(s);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
        
        addSARSensorChar(sensor);
        
        for (String string : sensor.getInstrumentModesDescriptions().keySet()) {
            
            this.addSARInstrumentMode(string, sensor.getInstrumentModesDescriptions().get(string));
        }
    }
    
    
    /**
     * 
     * @param sensor
     * @throws SQLException 
     */
    private void addOPTSensorChar(OPTSensor sensor) throws SQLException {
        
        
        String table = "OptSensorCharacteristics";
        
        List<String> fields = new ArrayList<String>();
        fields.add("acrossTrackFOV");
        fields.add("minAcrossTrackAngle");
        fields.add("maxAcrossTrackAngle");
        fields.add("minAlongTrackAngle");
        fields.add("maxAlongTrackAngle");
        fields.add("swathWidth");
        fields.add("groundLocationAccuracy");
        fields.add("revisitTimeInDays");
        fields.add("numberOfBands");
        
        
        fields.add("sensor");
        
        List<String> optChar = new ArrayList<String>();
        optChar.add(sensor.getAcrossTrackFOV());
        optChar.add(sensor.getMinAcrossTrackAngle());
        optChar.add(sensor.getMaxAcrossTrackAngle());
        optChar.add(sensor.getMinAlongTrackAngle());
        optChar.add(sensor.getMaxAlongTrackAngle());
        optChar.add(sensor.getSwathWidth());
        optChar.add(sensor.getGroundLocationAccuracy());
        optChar.add(sensor.getRevisitTimeInDays());
        optChar.add(sensor.getNumberOfBands());
        
        
        optChar.add(sensor.getSensorId());
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(optChar);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
        
        for (String string : sensor.getInstrumentModesDescriptions().keySet()) {
            this.addOPTInstrumentMode(string, sensor.getInstrumentModesDescriptions().get(string));
        }
    }
    
    /**
     * 
     * @param sensorId
     * @param sensorMode
     * @throws SQLException 
     */
    private void addOPTInstrumentMode(String sensorId, OPTSensor.OPTSensorMode sensorMode) throws SQLException {
        
        String table = "InstrumentMode";
        
        List<String> fields = new ArrayList<String>();
        fields.add("imId");
        fields.add("name");
        fields.add("description");

        List<String> im = new ArrayList<String>();
        im.add(sensorMode.getId());
        im.add(sensorMode.getName());
        im.add(sensorMode.getDescription());
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(im);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
        
        this.addOPTInstrumentModesChar(sensorId, sensorMode);
    }
    
    /**
     * 
     * @param sensorId
     * @param sensorMode
     * @throws SQLException 
     */
    private void addOPTInstrumentModesChar (String sensorId, OPTSensor.OPTSensorMode sensorMode) throws SQLException {
        
        
        String table = "OptImCharacteristics";
        
        List<String> fields = new ArrayList<String>();
        fields.add("acrossTrackResolution");
        fields.add("alongTrackResolution");
        
        fields.add("maxPowerConsumption");
        fields.add("numberOfSamples");
        fields.add("bandType");
        fields.add("minSpectralRange");
        fields.add("maxSpectralRange");
        fields.add("snrRatio");
        fields.add("noiseEquivalentRadiance");
        
        //Foreign key
        fields.add("instMode");
        fields.add("sensor");
        
        // MSI (Multi spectral instrument)
        List<String> s1Char = new ArrayList<String>();
        fields.add(sensorMode.getAcrossTrackResolution());
        fields.add(sensorMode.getAlongTrackResolution());
        
        fields.add(sensorMode.getMaxPowerConsumption());
        fields.add(sensorMode.getNumberOfSamples());
        fields.add(sensorMode.getBandType());
        fields.add(sensorMode.getMinSpectralRange());
        fields.add(sensorMode.getMaxSpectralRange());
        fields.add(sensorMode.getSnrRatio());
        fields.add(sensorMode.getNoiseEquivalentRadiance());
        
        //Foreign key
        fields.add(sensorMode.getId());
        fields.add(sensorId);
        
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(s1Char);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
    }
    
    /**
     * 
     * @param sensor
     * @throws SQLException 
     */
    private void addSARSensorChar(SARSensor sensor) throws SQLException {
        
        
        String table = "SarSensorCharacteristics";
        
        List<String> fields = new ArrayList<String>();
        fields.add("antennaLength");
        fields.add("antennaWidth");
        fields.add("groundLocationAccuracy");
        fields.add("revisitTimeInDays");
        fields.add("transmitFrequencyBand");
        fields.add("transmitCenterFrequency");
        
        fields.add("sensor");
        
        List<String> s1Char = new ArrayList<String>();
        fields.add(sensor.getAntennaLength());
        fields.add(sensor.getAntennaWidth());
        fields.add(sensor.getGroundLocationAccuracy());
        fields.add(sensor.getRevisitTimeInDays());
        fields.add(sensor.getTransmitFrequencyBand());
        fields.add(sensor.getTransmitCenterFrequency());
        
        fields.add(sensor.getSensorId());
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(s1Char);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
    }
    
    /**
     * 
     * @param sensorId
     * @param sensorMode
     * @throws SQLException 
     */
    private void addSARInstrumentMode(String sensorId, SARSensor.SARSensorMode sensorMode) throws SQLException {
        
        String table = "InstrumentMode";
        
        List<String> fields = new ArrayList<String>();
        fields.add("imId");
        fields.add("name");
        fields.add("description");

        List<String> im = new ArrayList<String>();
        im.add(sensorMode.getId());
        im.add(sensorMode.getName());
        im.add(sensorMode.getDescription());
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(im);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
        
        this.addSARInstrumentModesChar(sensorId, sensorMode);
    }
    
    /**
     * 
     * @param sensorId
     * @param sensorMode
     * @throws SQLException 
     */
    private void addSARInstrumentModesChar (String sensorId, SARSensor.SARSensorMode sensorMode) throws SQLException {
        
        String table = "SarImCharacteristics";
        
        List<String> fields = new ArrayList<String>();
        
        fields.add("acrossTrackResolution");
        fields.add("alongTrackResolution");
        
        fields.add("maxPowerConsumption");
        fields.add("minAcrossTrackAngle");
        fields.add("maxAcrossTrackAngle");
        fields.add("minAlongTrackAngle");
        fields.add("maxAlongTrackAngle");
        fields.add("swathWidth");
        fields.add("radiometricResolution");
        fields.add("minRadioStab");
        fields.add("maxRadioStab");
        fields.add("minAlongTrackAmbRatio");
        fields.add("maxAlongTrackAmbRatio");
        fields.add("minAcrossTrackAmbRatio");
        fields.add("maxAcrossTrackAmbRatio");
        fields.add("minNoiseEquivalentSO");
        fields.add("maxNoiseEquivalentSO");
        
        //Foreign key
        fields.add("instMode");
        fields.add("sensor");
        
        // Stripmap (SM)
        List<String> sarChar = new ArrayList<String>();
        
        sarChar.add(sensorMode.getAcrossTrackResolution());
        sarChar.add(sensorMode.getAlongTrackResolution());
        
        sarChar.add(sensorMode.getMaxPowerConsumption());
        sarChar.add(sensorMode.getMinAcrossTrackAngle());
        sarChar.add(sensorMode.getMaxAcrossTrackAngle());
        sarChar.add(sensorMode.getMinAlongTrackAngle());
        sarChar.add(sensorMode.getMaxAlongTrackAngle());
        sarChar.add(sensorMode.getSwathWidth());
        sarChar.add(sensorMode.getRadiometricResolution());
        sarChar.add(sensorMode.getMinRadioStab());
        sarChar.add(sensorMode.getMaxRadioStab());
        sarChar.add(sensorMode.getMinAlongTrackAmbRatio());
        sarChar.add(sensorMode.getMaxAlongTrackAmbRatio());
        sarChar.add(sensorMode.getMinAcrossTrackAmbRatio());
        sarChar.add(sensorMode.getMaxAcrossTrackAmbRatio());
        sarChar.add(sensorMode.getMinNoiseEquivalentSO());
        sarChar.add(sensorMode.getMaxNoiseEquivalentSO());
        
        //Foreign key
        sarChar.add(sensorMode.getId());
        sarChar.add(sensorId);
        
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(sarChar);
        
        String instrumentModeId = this.getDboperations().insertReturningId(
                table, 
                fields, 
                values,
                "instrumentModeId");
        
        for (String polMode : sensorMode.getPolarizationModes().keySet()) {
            this.addSARSensorPolarizationModes(instrumentModeId, polMode, sensorMode.getPolarizationModes().get(polMode));
        }
    }
    
    /**
     * 
     * @param instModeId
     * @param id
     * @param name
     * @throws SQLException 
     */
    private void addSARSensorPolarizationModes(String instModeId, String id, String name) throws SQLException {
        
        String table = "PolarisationMode";
        
        List<String> fields = new ArrayList<String>();
        fields.add("pmId");
        fields.add("name");
        fields.add("description");

        List<String> pm = new ArrayList<String>();
        pm.add(id);
        pm.add(name);
        pm.add(id + " - " + name);
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(pm);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
        
        this.addInstrumentModePolarisationModeJointures(instModeId, id);
    }
    
    /**
     * 
     * @param instMode
     * @param polMode
     * @throws SQLException 
     */
    private void addInstrumentModePolarisationModeJointures(String instMode, String polMode) throws SQLException {

        
        String table = "lnk_im_pm";
        
        List<String> fields = new ArrayList<String>();
        fields.add("instMode");
        fields.add("polMode");

        List<String> lnk = new ArrayList<String>();
        lnk.add("" + instMode);
        lnk.add("" + polMode);
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(lnk);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
    }
    
}
