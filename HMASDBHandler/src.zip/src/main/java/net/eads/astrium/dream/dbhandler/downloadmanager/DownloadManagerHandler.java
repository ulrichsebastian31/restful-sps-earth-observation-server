/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler.downloadmanager;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import net.eads.astrium.dream.dbhandler.DBOperations;
import net.eads.astrium.dream.dbhandler.DatabaseLoader;
import net.eads.astrium.dream.util.DateHandler;
import net.eads.astrium.dream.util.structures.downloadmanager.DownloadManager;
import net.eads.astrium.dream.util.structures.downloadmanager.errors.DMMError;

/**
 *
 * @author re-sulrich
 */
public class DownloadManagerHandler extends DatabaseLoader {

    private ErrorHandler errorHandler;
    
    public DownloadManagerHandler() {
        super("DownloadManagerDatabase");
        errorHandler = new ErrorHandler(this.getDboperations());
    }

    public DownloadManagerHandler(DBOperations dboperations) {
        super(dboperations);
        errorHandler = new ErrorHandler(this.getDboperations());
    }

    public DownloadManagerHandler(String databaseURL, String user, String pass) {
        super(databaseURL, user, pass);
        errorHandler = new ErrorHandler(this.getDboperations());
    }
    
    /**
     * INSERT INTO DownloadManager (downloadManagerID, name, status, refreshPeriod, deconnectionPeriod, lastActivityTime, startTime, user, monitoring)
     * VALUES (<manager.getDatabaseManagerID()>,<manager.getDatabaseManagerName()>,<manager.getStatus()>,<manager.getRefreshPeriod()>,
     * <manager.getDeconnectionPeriod()>,<manager.getLastActivityTime()>,<manager.getStartTime()>,<manager.getUserID()>, <monitoringServiceID>)
     * @param manager 
     */
    public void addDownloadManager(DownloadManager manager) throws SQLException {
        
        String table = "DownloadManager";

        List<String> fields = new ArrayList<String>();

        fields.add("downloadManagerID");
        fields.add("name");
        fields.add("status");
        fields.add("refreshPeriod");
        fields.add("deconnectionPeriod");
        fields.add("lastActivityTime");
        fields.add("startTime");

        //Foreign keys
        fields.add("userID");

        List<String> depl1 = new ArrayList<String>();
        depl1.add("'" + manager.getDatabaseManagerID() + "'");
        depl1.add("'" + manager.getDatabaseManagerName() + "'");
        depl1.add("'" + manager.getStatus() + "'");
        depl1.add("" + manager.getRefreshPeriod());
        depl1.add("" + manager.getDeconnectionPeriod());
        depl1.add("'" + DateHandler.formatDate(manager.getLastActivityTime()) + "'");
        depl1.add("'" + DateHandler.formatDate(manager.getStartTime()) + "'");

        //Foreign keys
        depl1.add("'" + manager.getUserID() + "'");

        List<List<String>> values = new ArrayList<List<String>>();
        values.add(depl1);

        this.getDboperations().insert(
                table,
                fields,
                values);

    }
    
    
    /**
     * UPDATE DownloadManager SET (
     *  DownloadManager.status='ERROR',
     *  DownloadManager.lastActivityTime=<NOW>
     * ) = WHERE downloadManagerID=<downloadManagerID> ;
     * INSERT INTO Error 
     * (errorCode,errorMessage,errorDescription, downloadManager) 
     * VALUES (<error.getErrorCode()>, <error.getErrorMessage()>, <error.getErrorDescription()>, <downloadManagerID>);
     * @param downloadManagerID
     * @param error 
     */    
    public String setError(String downloadManagerID, DMMError error) throws SQLException {
        return this.errorHandler.addError(true, downloadManagerID, error);
    }
    
    public void setStatus(String downloadManagerID, String status) throws SQLException {
        
        String table = "DownloadManager";

        List<String> fields = new ArrayList<String>();
        fields.add("status");
        
        List<String> depl1 = new ArrayList<String>();
        depl1.add("'" + status + "'");
        
        String condition = "downloadManagerID='" + downloadManagerID + "'";
        
        this.getDboperations().update(table, fields, depl1, condition);
    }
    
    
    /*
     * Reading from the database
     */
    public boolean isDownloadManagerRegistered(String downloadManagerID) throws SQLException {
        
        boolean isReg = false;
        
        List<String> fields = new ArrayList<String>();
        fields.add("*");

        String table = "DownloadManager";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("downloadManagerID='" + downloadManagerID + "'");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);
        
        if (result != null && result.size() > 0) {
            isReg = true;
        }
        
        return isReg;
    }
    
    public String getStatus(String downloadManagerID) throws SQLException {
        
        String status = null;
        
        List<String> fields = new ArrayList<String>();
        fields.add("status");

        String table = "DownloadManager";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("downloadManagerID='" + downloadManagerID + "'");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);
        
        if (result != null && result.size() > 0) {
            
            status = result.get(0).get(0);
        }
        
        return status;
    }

    public int getDownloadManagerRefreshTime(String downloadManagerID) throws ParseException, SQLException {
        
        int dmRefresh = 0;
        
        List<String> fields = new ArrayList<String>();
        fields.add("refreshPeriod");

        String table = "DownloadManager";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("downloadManagerID='" + downloadManagerID + "'");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);
        
        if (result != null && result.size() > 0) {
            
            dmRefresh = Integer.valueOf(result.get(0).get(0));
        }
        
        return dmRefresh;
    }

    public DownloadManager getDownloadManager(String downloadManagerID) throws ParseException, SQLException {
        
        DownloadManager dm = null;
        
        List<String> fields = new ArrayList<String>();
//        fields.add("downloadManagerID");
        fields.add("name");
        fields.add("status");
        fields.add("refreshPeriod");
        fields.add("deconnectionPeriod");
        fields.add("lastActivityTime");
        fields.add("startTime");

        //Foreign keys
        fields.add("userID");

        String table = "DownloadManager";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<String>();
        conditions.add("downloadManagerID='" + downloadManagerID + "'");

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);
        
        if (result != null && result.size() > 0) {
            
            dm = new DownloadManager(
                    downloadManagerID, 
                    result.get(0).get(0),                               //name
                    result.get(0).get(6),                               //userID
                    result.get(0).get(1),                               
                    Integer.valueOf(result.get(0).get(2)), 
                    Integer.valueOf(result.get(0).get(3)), 
                    DateHandler.parseBDDDate(result.get(0).get(4)), 
                    DateHandler.parseBDDDate(result.get(0).get(5)));
        }
        
        return dm;
    }

    public List<String> getDataAccessRequestsIDs(String downloadManagerID, Date setTime) throws ParseException, SQLException {
        
        List<String> dars = new ArrayList<>();
        
        List<String> fields = new ArrayList<>();
        fields.add("darID");
        fields.add("creationTime");

        String table = "DataAccessRequest";

        //Filtering the DB results by app server
        List<String> conditions = new ArrayList<>();
        conditions.add("manager='" + downloadManagerID + "'");
        
        if (setTime != null) {
            conditions.add("creationTime>'" + DateHandler.formatDate(setTime) + "'");
        }

        List<List<String>> result = this.getDboperations().select(fields, table, conditions);
        
        if (result != null && result.size() > 0) {
            for (List<String> list : result) {
                dars.add(list.get(0));
            }
        }
        
        return dars;
    }

    public List<DMMError> getErrors(String downloadManagerID) throws SQLException {
        return this.errorHandler.getErrors(true, downloadManagerID);
    }
}
