/**
 * --------------------------------------------------------------------------------------------------------
 *   Project                                            :               DREAM
 * --------------------------------------------------------------------------------------------------------
 *   File Name                                          :               MMFASHandler.java
 *   File Type                                          :               Source Code
 *   Description                                        :                *
 * --------------------------------------------------------------------------------------------------------
 *
 * =================================================================
 *             (coffee) COPYRIGHT EADS ASTRIUM LIMITED 2013. All Rights Reserved
 *             This software is supplied by EADS Astrium Limited on the express terms
 *             that it is to be treated as confidential and that it may not be copied,
 *             used or disclosed to others for any purpose except as authorised in
 *             writing by this Company.
 * --------------------------------------------------------------------------------------------------------
 *//*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.eads.astrium.dream.util.structures.Orbit;
import net.eads.astrium.dream.util.structures.SatellitePlatform;

/**
 *
 * @author re-sulrich
 */
public class MMFASHandler extends SensorLoader {
    
    private final String mmfasId;

    public MMFASHandler(String mmfasId) {
        
        super(ConditionType.mmfas, mmfasId);
        
        this.mmfasId = mmfasId;
    }
    
    public MMFASHandler(String mmfasId, DBOperations dboperations) {
        
        super(ConditionType.mmfas, mmfasId, dboperations);
        this.mmfasId = mmfasId;
    }
    
    public MMFASHandler(String mmfasId, String databaseURL, String user, String pass) {
        
        super(ConditionType.mmfas, mmfasId, databaseURL, user, pass);
        
        this.mmfasId = mmfasId;
    }
    
    public List<String> getSatellitesIds() throws SQLException {
        
        List<String> satellites = new ArrayList<String>();

        //Fields needed to fill in the Sensor structures
        List<String> fields = new ArrayList<String>();
        fields.add("satelliteId");
        
        String table = "SatellitePlatform";
        
        List<String> conditions = new ArrayList<String>();
        conditions.add("satelliteId in "
                + "(SELECT satellite FROM LNK_MMFAS_Satellite WHERE mmfas = '" + mmfasId + "')"
            );
        
        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        for (List<String> entry : result) {

            List<String> list = entry;

            satellites.add(
                    list.get(0)
                    );
            
        }
        
        return satellites;
    }
    
    public List<SatellitePlatform> getSatellites(String sensorType) throws SQLException {
        
        List<SatellitePlatform> satellites = new ArrayList<SatellitePlatform>();

        //Fields needed to fill in the Sensor structures
        List<String> fields = new ArrayList<String>();
        fields.add("satelliteId");
        fields.add("noradName");
        fields.add("name");
        fields.add("description");
        fields.add("href");

        fields.add("orbitType");
        fields.add("low_Min_Semi_Major_Axis");
        fields.add("low_Max_Semi_Major_Axis");
        fields.add("low_Min_Inclination");
        fields.add("low_Max_Inclination");
        fields.add("low_Min_Eccentricity");
        fields.add("low_Max_Eccentricity");
        fields.add("tight_Min_Semi_Major_Axis");
        fields.add("tight_Max_Semi_Major_Axis");
        fields.add("tight_Min_Inclination");
        fields.add("tight_Max_Inclination");
        fields.add("tight_Min_Eccentricity");
        fields.add("tight_Max_Eccentricity");
        fields.add("orbit_Min_Semi_Major_Axis");
        fields.add("orbit_Nom_Semi_Major_Axis");
        fields.add("orbit_Max_Semi_Major_Axis");
        fields.add("orbit_Min_Inclination");
        fields.add("orbit_Nom_Inclination");
        fields.add("orbit_Max_Inclination");
        fields.add("orbit_Nom_Eccentricity");
        fields.add("orbit_Nom_Arg_Perigee");
        
        String table = "SatellitePlatform, Orbit, Sensor";
        
        List<String> conditions = new ArrayList<String>();
        conditions.add("satelliteId in "
                + "(SELECT satellite FROM LNK_MMFAS_Satellite WHERE mmfas = '" + mmfasId + "')"
            );
        conditions.add("SatellitePlatform.satelliteId= Orbit.satellite");
        conditions.add("SatellitePlatform.satelliteId= Sensor.platform");
        conditions.add("Sensor.type= '"+sensorType+"'");
        
        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        for (List<String> entry : result) {

            List<String> list = entry;

            satellites.add(
                    new SatellitePlatform(
                    list.get(0), 
                    list.get(1), 
                    list.get(2), 
                    list.get(3), 
                    list.get(4), 
                    new Orbit(list.get(5), 
                        list.get(6), 
                        list.get(7), 
                        list.get(8), 
                        list.get(9), 
                        list.get(10), 
                        list.get(11), 
                        list.get(12), 
                        list.get(13), 
                        list.get(14), 
                        list.get(15), 
                        list.get(16), 
                        list.get(17), 
                        list.get(18), 
                        list.get(19), 
                        list.get(20), 
                        list.get(21), 
                        list.get(22), 
                        list.get(23), 
                        list.get(24), 
                        list.get(25)))
                    );
            
        }
        
        return satellites;
    }
    
    public List<SatellitePlatform> getSatellites() throws SQLException {
        
        List<SatellitePlatform> satellites = new ArrayList<SatellitePlatform>();

        //Fields needed to fill in the Sensor structures
        List<String> fields = new ArrayList<String>();
        fields.add("satelliteId");
        fields.add("noradName");
        fields.add("name");
        fields.add("description");
        fields.add("href");

        fields.add("orbitType");
        fields.add("low_Min_Semi_Major_Axis");
        fields.add("low_Max_Semi_Major_Axis");
        fields.add("low_Min_Inclination");
        fields.add("low_Max_Inclination");
        fields.add("low_Min_Eccentricity");
        fields.add("low_Max_Eccentricity");
        fields.add("tight_Min_Semi_Major_Axis");
        fields.add("tight_Max_Semi_Major_Axis");
        fields.add("tight_Min_Inclination");
        fields.add("tight_Max_Inclination");
        fields.add("tight_Min_Eccentricity");
        fields.add("tight_Max_Eccentricity");
        fields.add("orbit_Min_Semi_Major_Axis");
        fields.add("orbit_Nom_Semi_Major_Axis");
        fields.add("orbit_Max_Semi_Major_Axis");
        fields.add("orbit_Min_Inclination");
        fields.add("orbit_Nom_Inclination");
        fields.add("orbit_Max_Inclination");
        fields.add("orbit_Nom_Eccentricity");
        fields.add("orbit_Nom_Arg_Perigee");
        
        String table = "SatellitePlatform, Orbit";
        
        List<String> conditions = new ArrayList<String>();
        conditions.add("satelliteId in "
                + "(SELECT satellite FROM LNK_MMFAS_Satellite WHERE mmfas = '" + mmfasId + "')"
            );
        conditions.add("SatellitePlatform.satelliteId= Orbit.satellite");
        
        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        for (List<String> entry : result) {

            List<String> list = entry;
            
            satellites.add(
                    new SatellitePlatform(
                    list.get(0), 
                    list.get(1), 
                    list.get(2), 
                    list.get(3), 
                    list.get(4), 
                    new Orbit(list.get(5), 
                        list.get(6), 
                        list.get(7), 
                        list.get(8), 
                        list.get(9), 
                        list.get(10), 
                        list.get(11), 
                        list.get(12), 
                        list.get(13), 
                        list.get(14), 
                        list.get(15), 
                        list.get(16), 
                        list.get(17), 
                        list.get(18), 
                        list.get(19), 
                        list.get(20), 
                        list.get(21), 
                        list.get(22), 
                        list.get(23), 
                        list.get(24), 
                        list.get(25)))
                    );
            
        }
        
        return satellites;
    }
    
    /**
     * Returns a map containing the SensorID as the key and the FAS' base address as the value
     * @param sensorType    Type of sensor desired; values are OPT, SAR
     * @return
     * @throws SQLException 
     */
    public Map<String, String> getInternalFASs(String sensorType) throws SQLException {
        
        Map<String, String> sensorsFAS = new HashMap<String, String>();
        
        //Fields needed to fill in the Sensor structures
        List<String> fields = new ArrayList<String>();
        fields.add("Sensor.sensorId");
        fields.add("FAS.fasId");
        fields.add("ApplicationServer.serverBaseAddress");
        
        String table = "FAS, ApplicationServer, Sensor";
        
        List<String> conditions = new ArrayList<String>();
        conditions.add("Sensor.platform in "
                + "(SELECT satellite FROM LNK_MMFAS_Satellite WHERE mmfas = '" + mmfasId + "')"
            );
        conditions.add("Sensor.platform = FAS.platform");
        conditions.add("FAS.externalFAS='FALSE'");
        conditions.add("ApplicationServer.asId= FAS.server");
        conditions.add("Sensor.type= '"+sensorType+"'");
        
        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            for (List<String> list : result) {
                
                sensorsFAS.put(
                        list.get(0),                                                    //SensorId
                        (list.get(2) + "/DreamServices/dream/fas/" + list.get(1) + "/")  //Server base address
                    );
            }
        }
        
        return sensorsFAS;
    }
    
    /**
     * Returns a map containing the SensorID as the key and the FAS' base address as the value
     * @param sensorType    Type of sensor desired; values are OPT, SAR
     * @return
     * @throws SQLException 
     */
    public Map<String, String> getExternalFASs(String sensorType) throws SQLException {
        
        Map<String, String> sensorsFAS = new HashMap<String, String>();
        
        //Fields needed to fill in the Sensor structures
        List<String> fields = new ArrayList<String>();
        fields.add("Sensor.sensorId");
        fields.add("FAS.fasId");
        fields.add("FAS.externalHref");
        
        String table = "FAS, ApplicationServer, Sensor";
        
        List<String> conditions = new ArrayList<String>();
        conditions.add("Sensor.platform in "
                + "(SELECT satellite FROM LNK_MMFAS_Satellite WHERE mmfas = '" + mmfasId + "')"
            );
        conditions.add("Sensor.platform = FAS.platform");
        conditions.add("FAS.externalFAS='TRUE'");
        conditions.add("Sensor.type= '"+sensorType+"'");
        
        List<List<String>> result = this.getDboperations().select(fields, table, conditions);

        if (result != null && result.size() > 0) {
            for (List<String> list : result) {
                
                sensorsFAS.put(
                        list.get(0),    //SensorId
                        list.get(2)    //Server base address
                    );
            }
        }
        
        return sensorsFAS;
    }
}
