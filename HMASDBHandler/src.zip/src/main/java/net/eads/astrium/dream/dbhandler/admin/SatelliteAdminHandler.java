/**
 * --------------------------------------------------------------------------------------------------------
 *   Project                                            :               DREAM
 * --------------------------------------------------------------------------------------------------------
 *   File Name                                          :               SatelliteAdminHandler.java
 *   File Type                                          :               Source Code
 *   Description                                        :                *
 * --------------------------------------------------------------------------------------------------------
 *
 * =================================================================
 *             (coffee) COPYRIGHT EADS ASTRIUM LIMITED 2013. All Rights Reserved
 *             This software is supplied by EADS Astrium Limited on the express terms
 *             that it is to be treated as confidential and that it may not be copied,
 *             used or disclosed to others for any purpose except as authorised in
 *             writing by this Company.
 * --------------------------------------------------------------------------------------------------------
 *//*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.eads.astrium.dream.dbhandler.admin;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import net.eads.astrium.dream.dbhandler.DatabaseLoader;
import net.eads.astrium.dream.util.structures.Orbit;

/**
 *
 * @author re-sulrich
 */
public class SatelliteAdminHandler extends DatabaseLoader {
    
    public SatelliteAdminHandler() {
        super("MMFASDatabase");
    }
    
    public void addSatellite(
            String satelliteId, 
            String noradName, 
            String name, 
            String description, 
            String href, 
            Orbit orbit) throws SQLException {
        String table = "SatellitePlatform";
        
        List<String> fields = new ArrayList<String>();
        fields.add("satelliteId");
        fields.add("noradName");
        fields.add("name");
        fields.add("description");
        fields.add("href");


        List<String> sentinel1 = new ArrayList<String>();
        sentinel1.add("'"+satelliteId+"'");
        sentinel1.add("'"+noradName+"'");
        sentinel1.add("'"+name+"'");
        sentinel1.add("'"+description+"'");
        sentinel1.add("'"+href+"'");
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(sentinel1);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
        
        this.addSatelliteOrbit(orbit);
    }
    
    private void addSatelliteOrbit(Orbit orbit) throws SQLException {
        
        String table = "Orbit";
        
        List<String> fields = new ArrayList<String>();
        
        fields.add("orbitType");
        fields.add("low_Min_Semi_Major_Axis");
        fields.add("low_Max_Semi_Major_Axis");
        fields.add("low_Min_Inclination");
        fields.add("low_Max_Inclination");
        fields.add("low_Min_Eccentricity");
        fields.add("low_Max_Eccentricity");
        fields.add("tight_Min_Semi_Major_Axis");
        fields.add("tight_Max_Semi_Major_Axis");
        fields.add("tight_Min_Inclination");
        fields.add("tight_Max_Inclination");
        fields.add("tight_Min_Eccentricity");
        fields.add("tight_Max_Eccentricity");
        fields.add("orbit_Min_Semi_Major_Axis");
        fields.add("orbit_Nom_Semi_Major_Axis");
        fields.add("orbit_Max_Semi_Major_Axis");
        fields.add("orbit_Min_Inclination");
        fields.add("orbit_Nom_Inclination");
        fields.add("orbit_Max_Inclination");
        fields.add("orbit_Nom_Eccentricity");
        fields.add("orbit_Nom_Arg_Perigee");
        
        fields.add("satellite");
        
        List<String> o = new ArrayList<String>();
        
        o.add("'"  + orbit.getOrbitType() + "'");
        o.add(orbit.getLow_Min_Semi_Major_Axis());
        o.add(orbit.getLow_Max_Semi_Major_Axis());
        o.add(orbit.getLow_Min_Inclination());
        o.add(orbit.getLow_Max_Inclination());
        o.add(orbit.getLow_Min_Eccentricity());
        o.add(orbit.getLow_Max_Eccentricity());
        o.add(orbit.getTight_Min_Semi_Major_Axis());
        o.add(orbit.getTight_Max_Semi_Major_Axis());
        o.add(orbit.getTight_Min_Inclination());
        o.add(orbit.getTight_Max_Inclination());
        o.add(orbit.getTight_Min_Eccentricity());
        o.add(orbit.getTight_Max_Eccentricity());
        o.add(orbit.getOrbit_Min_Semi_Major_Axis());
        o.add(orbit.getOrbit_Nom_Semi_Major_Axis());
        o.add(orbit.getOrbit_Max_Semi_Major_Axis());
        o.add(orbit.getOrbit_Min_Inclination());
        o.add(orbit.getOrbit_Nom_Inclination());
        o.add(orbit.getOrbit_Max_Inclination());
        o.add(orbit.getOrbit_Nom_Eccentricity());
        o.add(orbit.getOrbit_Nom_Arg_Perigee());
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(o);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
    }
    
    public void addInternalFAS(
            String fasId, 
            String satelliteId, 
            String serverId) throws SQLException {
        String table = "FAS";
        
        List<String> fields = new ArrayList<String>();
        fields.add("fasId");
        fields.add("externalFAS");
        
        fields.add("platform");
        fields.add("server");
        

        List<String> sentinel1 = new ArrayList<String>();
        sentinel1.add("'"+fasId+"'");
        sentinel1.add("false");
        sentinel1.add("'"+satelliteId+"'");
        sentinel1.add("'"+serverId+"'");
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(sentinel1);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
    }
    
    public void addExternalFAS(
            String fasId, 
            String href, 
            String satelliteId) throws SQLException {
        String table = "FAS";
        
        List<String> fields = new ArrayList<String>();
        fields.add("fasId");
        fields.add("externalFAS");
        fields.add("externalHref");
        
        fields.add("platform");
        

        List<String> sentinel1 = new ArrayList<String>();
        sentinel1.add("'"+fasId+"'");
        sentinel1.add("true");
        sentinel1.add("'"+href+"'");
        
        sentinel1.add("'"+satelliteId+"'");
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(sentinel1);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
    }
    
    public void addInternalMissionPlanner(
            String missionPlannerId, 
            String name, 
            String description, 
            String satelliteId, 
            String serverId) throws SQLException {
        String table = "MissionPlanner";
        
        List<String> fields = new ArrayList<String>();
        fields.add("mpId");
        fields.add("name");
        fields.add("description");
        fields.add("externalMP");
        
        fields.add("platform");
        fields.add("server");
        

        List<String> sentinel1 = new ArrayList<String>();
        sentinel1.add("'"+missionPlannerId+"'");
        sentinel1.add("'"+name+"'");
        sentinel1.add("'"+description+"'");
        sentinel1.add("false");
        sentinel1.add("'"+satelliteId+"'");
        sentinel1.add("'"+serverId+"'");
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(sentinel1);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
    }
    
    public void addExternalMissionPlanner(
            String missionPlannerId, 
            String name, 
            String description, 
            String href, 
            String satelliteId) throws SQLException {
        String table = "MissionPlanner";
        
        List<String> fields = new ArrayList<String>();
        fields.add("mpId");
        fields.add("name");
        fields.add("description");
        fields.add("externalMP");
        fields.add("externalHref");
        
        fields.add("platform");
        

        List<String> sentinel1 = new ArrayList<String>();
        sentinel1.add("'"+missionPlannerId+"'");
        sentinel1.add("'"+name+"'");
        sentinel1.add("'"+description+"'");
        sentinel1.add("true");
        sentinel1.add("'"+href+"'");
        
        sentinel1.add("'"+satelliteId+"'");
        
        List<List<String>> values = new ArrayList<List<String>>();
        values.add(sentinel1);
        
        this.getDboperations().insert(
                table, 
                fields, 
                values);
    }
}
